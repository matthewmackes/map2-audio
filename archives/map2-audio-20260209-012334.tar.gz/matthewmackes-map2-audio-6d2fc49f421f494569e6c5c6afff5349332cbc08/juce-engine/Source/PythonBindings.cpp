/**
 * MAP2 Audio Engine - Python Bindings
 * pybind11 module exposing the audio engine to Python
 * Version 2.0 - Full JUCE Integration with advanced metering
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>

#include "Map2AudioEngine.h"
#include "SpectrumAnalyzer.h"
#include "LufsMeter.h"
#include "PhaseCorrelation.h"
#include "CPUMonitor.h"
#include "ConvolutionProcessor.h"
#include "DynamicsProcessor.h"
#include "FilterProcessor.h"
#include "MidiHandler.h"
#include "ChorusProcessor.h"
#include "PhaserProcessor.h"
#include "PitchShifterProcessor.h"
#include "DelayProcessor.h"
#include "IntelliFX8VoiceChorusProcessor.h"
#include "BossXS1PolyShifterProcessor.h"
#include "ShoeGazeProcessor.h"
#include "LexiLoveProcessor.h"
#include "H3000Processor.h"

namespace py = pybind11;
using namespace map2;

// ========================================
// Type Converters
// ========================================

// Convert PluginInfo to Python dict
py::dict pluginInfoToDict(const PluginInfo& info) {
    py::dict d;
    d["uri"] = info.uri;
    d["name"] = info.name;
    d["author"] = info.author;
    d["brand"] = info.brand;
    d["category"] = info.category;
    d["license"] = info.license;
    d["version"] = info.version;
    d["audio_inputs"] = info.audioInputs;
    d["audio_outputs"] = info.audioOutputs;
    d["has_midi_input"] = info.hasMidiInput;
    d["has_midi_output"] = info.hasMidiOutput;
    d["format"] = pluginFormatToString(info.format);
    d["format_name"] = info.formatName;
    d["file_path"] = info.filePath;
    d["latency_samples"] = info.latencySamples;

    py::list params;
    for (const auto& param : info.parameters) {
        py::dict p;
        p["index"] = param.index;
        p["symbol"] = param.symbol;
        p["name"] = param.name;
        p["min_value"] = param.minValue;
        p["max_value"] = param.maxValue;
        p["default_value"] = param.defaultValue;
        p["is_toggle"] = param.isToggle;
        p["is_integer"] = param.isInteger;
        p["is_logarithmic"] = param.isLogarithmic;
        params.append(p);
    }
    d["parameters"] = params;

    py::list ports;
    for (const auto& port : info.ports) {
        py::dict p;
        p["index"] = port.index;
        p["symbol"] = port.symbol;
        p["name"] = port.name;
        p["is_input"] = (port.direction == PortDirection::Input);
        p["is_audio"] = (port.type == PortType::Audio);
        p["is_control"] = (port.type == PortType::Control);
        ports.append(p);
    }
    d["ports"] = ports;

    return d;
}

// Convert VuLevels to Python dict
py::dict vuLevelsToDict(const VuLevels& vu) {
    py::dict d;
    d["input_left"] = vu.inputLeft;
    d["input_right"] = vu.inputRight;
    d["output_left"] = vu.outputLeft;
    d["output_right"] = vu.outputRight;
    return d;
}

// Convert Snapshot to Python dict
py::dict snapshotToDict(const Snapshot& snap) {
    py::dict d;
    d["id"] = snap.id;
    d["name"] = snap.name;
    return d;
}

// Convert LufsLevels to Python dict
py::dict lufsLevelsToDict(const LufsLevels& lufs) {
    py::dict d;
    d["momentary"] = lufs.momentary;
    d["short_term"] = lufs.shortTerm;
    d["integrated"] = lufs.integrated;
    d["range"] = lufs.range;
    d["true_peak"] = lufs.truePeak;
    d["true_peak_left"] = lufs.truePeakLeft;
    d["true_peak_right"] = lufs.truePeakRight;
    return d;
}

// Convert CPUMetrics to Python dict
py::dict cpuMetricsToDict(const CPUMetrics& metrics) {
    py::dict d;
    d["total_cpu_percent"] = metrics.totalCpuPercent;
    d["audio_callback_percent"] = metrics.audioCallbackPercent;
    d["peak_cpu_percent"] = metrics.peakCpuPercent;
    d["average_cpu_percent"] = metrics.averageCpuPercent;
    d["xrun_count"] = metrics.xrunCount;
    d["budget_ms"] = metrics.budgetMs;
    d["current_callback_ms"] = metrics.currentCallbackMs;
    d["headroom_percent"] = metrics.headroomPercent;

    py::dict perPlugin;
    for (const auto& [id, percent] : metrics.perPluginPercent) {
        perPlugin[py::cast(id)] = percent;
    }
    d["per_plugin_percent"] = perPlugin;

    return d;
}

// Convert SpectrumData to Python dict
py::dict spectrumDataToDict(const SpectrumAnalyzer::SpectrumData& spectrum) {
    py::dict d;

    py::list magnitudes;
    for (float m : spectrum.magnitudes) {
        magnitudes.append(m);
    }
    d["magnitudes"] = magnitudes;

    py::list frequencies;
    for (float f : spectrum.frequencies) {
        frequencies.append(f);
    }
    d["frequencies"] = frequencies;

    d["peak_frequency"] = spectrum.peakFrequency;
    d["peak_magnitude"] = spectrum.peakMagnitude;
    d["spectral_centroid"] = spectrum.spectralCentroid;

    return d;
}

// Convert SidechainConnection to Python dict
py::dict sidechainConnectionToDict(const SidechainConnection& conn) {
    py::dict d;
    d["source_plugin"] = conn.sourcePlugin;
    d["dest_plugin"] = conn.destPlugin;
    d["dest_bus"] = conn.destBus;
    d["active"] = conn.active;
    return d;
}

// Convert IRInfo to Python dict
py::dict irInfoToDict(const ConvolutionProcessor::IRInfo& info) {
    py::dict d;
    d["path"] = info.path;
    d["channels"] = info.numChannels;
    d["length_samples"] = info.lengthSamples;
    d["length_seconds"] = info.lengthSeconds;
    d["sample_rate"] = info.originalSampleRate;
    d["stereo"] = info.stereo;
    return d;
}

// Convert DynamicsProcessor::Mode to string
std::string dynamicsModeToString(DynamicsProcessor::Mode mode) {
    switch (mode) {
        case DynamicsProcessor::Mode::Compressor: return "compressor";
        case DynamicsProcessor::Mode::Limiter: return "limiter";
        case DynamicsProcessor::Mode::NoiseGate: return "noise_gate";
        default: return "compressor";
    }
}

// Convert string to DynamicsProcessor::Mode
DynamicsProcessor::Mode stringToDynamicsMode(const std::string& str) {
    if (str == "limiter") return DynamicsProcessor::Mode::Limiter;
    if (str == "noise_gate") return DynamicsProcessor::Mode::NoiseGate;
    return DynamicsProcessor::Mode::Compressor;
}

// Convert DynamicsProcessor::Parameters to Python dict
py::dict dynamicsParamsToDict(const DynamicsProcessor::Parameters& params) {
    py::dict d;
    d["threshold"] = params.threshold;
    d["ratio"] = params.ratio;
    d["attack"] = params.attack;
    d["release"] = params.release;
    d["knee"] = params.knee;
    d["makeup_gain"] = params.makeupGain;
    d["auto_makeup"] = params.autoMakeup;
    d["mode"] = dynamicsModeToString(params.mode);
    d["bypass"] = params.bypass;
    return d;
}

// Convert Python dict to DynamicsProcessor::Parameters
DynamicsProcessor::Parameters dictToDynamicsParams(const py::dict& d) {
    DynamicsProcessor::Parameters params;
    if (d.contains("threshold")) params.threshold = d["threshold"].cast<float>();
    if (d.contains("ratio")) params.ratio = d["ratio"].cast<float>();
    if (d.contains("attack")) params.attack = d["attack"].cast<float>();
    if (d.contains("release")) params.release = d["release"].cast<float>();
    if (d.contains("knee")) params.knee = d["knee"].cast<float>();
    if (d.contains("makeup_gain")) params.makeupGain = d["makeup_gain"].cast<float>();
    if (d.contains("auto_makeup")) params.autoMakeup = d["auto_makeup"].cast<bool>();
    if (d.contains("mode")) params.mode = stringToDynamicsMode(d["mode"].cast<std::string>());
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

// Convert DynamicsProcessor::Metering to Python dict
py::dict dynamicsMeteringToDict(const DynamicsProcessor::Metering& m) {
    py::dict d;
    d["input_level"] = m.inputLevel;
    d["output_level"] = m.outputLevel;
    d["gain_reduction"] = m.gainReduction;
    d["input_rms"] = m.inputRms;
    d["output_rms"] = m.outputRms;
    return d;
}

// ========================================
// Chorus Type Converters
// ========================================

// Convert ChorusProcessor::Parameters to Python dict
py::dict chorusParamsToDict(const ChorusProcessor::Parameters& params) {
    py::dict d;
    d["rate"] = params.rate;
    d["depth"] = params.depth;
    d["centre_delay"] = params.centreDelay;
    d["feedback"] = params.feedback;
    d["mix"] = params.mix;
    d["spread"] = params.spread;
    d["bypass"] = params.bypass;
    return d;
}

// Convert Python dict to ChorusProcessor::Parameters
ChorusProcessor::Parameters dictToChorusParams(const py::dict& d) {
    ChorusProcessor::Parameters params;
    if (d.contains("rate")) params.rate = d["rate"].cast<float>();
    if (d.contains("depth")) params.depth = d["depth"].cast<float>();
    if (d.contains("centre_delay")) params.centreDelay = d["centre_delay"].cast<float>();
    if (d.contains("feedback")) params.feedback = d["feedback"].cast<float>();
    if (d.contains("mix")) params.mix = d["mix"].cast<float>();
    if (d.contains("spread")) params.spread = d["spread"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

// Convert ChorusProcessor::Metering to Python dict
py::dict chorusMeteringToDict(const ChorusProcessor::Metering& m) {
    py::dict d;
    d["input_level"] = m.inputLevel;
    d["output_level"] = m.outputLevel;
    d["lfo_phase"] = m.lfoPhase;
    return d;
}

// ========================================
// Phaser Type Converters
// ========================================

// Convert PhaserProcessor::Parameters to Python dict
py::dict phaserParamsToDict(const PhaserProcessor::Parameters& params) {
    py::dict d;
    d["rate"] = params.rate;
    d["depth"] = params.depth;
    d["centre_frequency"] = params.centreFrequency;
    d["feedback"] = params.feedback;
    d["mix"] = params.mix;
    d["bypass"] = params.bypass;
    return d;
}

// Convert Python dict to PhaserProcessor::Parameters
PhaserProcessor::Parameters dictToPhaserParams(const py::dict& d) {
    PhaserProcessor::Parameters params;
    if (d.contains("rate")) params.rate = d["rate"].cast<float>();
    if (d.contains("depth")) params.depth = d["depth"].cast<float>();
    if (d.contains("centre_frequency")) params.centreFrequency = d["centre_frequency"].cast<float>();
    if (d.contains("feedback")) params.feedback = d["feedback"].cast<float>();
    if (d.contains("mix")) params.mix = d["mix"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

// Convert PhaserProcessor::Metering to Python dict
py::dict phaserMeteringToDict(const PhaserProcessor::Metering& m) {
    py::dict d;
    d["input_level"] = m.inputLevel;
    d["output_level"] = m.outputLevel;
    d["lfo_phase"] = m.lfoPhase;
    return d;
}

// ========================================
// Pitch Shifter Type Converters
// ========================================

// Convert PitchShifterProcessor::Preset to string
std::string pitchPresetToString(PitchShifterProcessor::Preset preset) {
    switch (preset) {
        case PitchShifterProcessor::Preset::Manual: return "manual";
        case PitchShifterProcessor::Preset::Eruption: return "eruption";
        case PitchShifterProcessor::Preset::Unchained: return "unchained";
        case PitchShifterProcessor::Preset::LittleGuitars: return "little_guitars";
        case PitchShifterProcessor::Preset::MeanStreet: return "mean_street";
        case PitchShifterProcessor::Preset::DropDeadLegs: return "drop_dead_legs";
        case PitchShifterProcessor::Preset::Panama: return "panama";
        case PitchShifterProcessor::Preset::Cathedral: return "cathedral";
        case PitchShifterProcessor::Preset::HotForTeacher: return "hot_for_teacher";
        case PitchShifterProcessor::Preset::WhyCantThisBeLove: return "why_cant_this_be_love";
        case PitchShifterProcessor::Preset::Dreams: return "dreams";
        case PitchShifterProcessor::Preset::FinishWhatYaStarted: return "finish_what_ya_started";
        case PitchShifterProcessor::Preset::RightNow: return "right_now";
        case PitchShifterProcessor::Preset::CantStopLovinYou: return "cant_stop_lovin_you";
        case PitchShifterProcessor::Preset::HumansBeingOuttro: return "humans_being_outtro";
        default: return "manual";
    }
}

// Convert string to PitchShifterProcessor::Preset
PitchShifterProcessor::Preset stringToPitchPreset(const std::string& str) {
    if (str == "eruption") return PitchShifterProcessor::Preset::Eruption;
    if (str == "unchained") return PitchShifterProcessor::Preset::Unchained;
    if (str == "little_guitars") return PitchShifterProcessor::Preset::LittleGuitars;
    if (str == "mean_street") return PitchShifterProcessor::Preset::MeanStreet;
    if (str == "drop_dead_legs") return PitchShifterProcessor::Preset::DropDeadLegs;
    if (str == "panama") return PitchShifterProcessor::Preset::Panama;
    if (str == "cathedral") return PitchShifterProcessor::Preset::Cathedral;
    if (str == "hot_for_teacher") return PitchShifterProcessor::Preset::HotForTeacher;
    if (str == "why_cant_this_be_love") return PitchShifterProcessor::Preset::WhyCantThisBeLove;
    if (str == "dreams") return PitchShifterProcessor::Preset::Dreams;
    if (str == "finish_what_ya_started") return PitchShifterProcessor::Preset::FinishWhatYaStarted;
    if (str == "right_now") return PitchShifterProcessor::Preset::RightNow;
    if (str == "cant_stop_lovin_you") return PitchShifterProcessor::Preset::CantStopLovinYou;
    if (str == "humans_being_outtro") return PitchShifterProcessor::Preset::HumansBeingOuttro;
    return PitchShifterProcessor::Preset::Manual;
}

// Convert PitchShifterProcessor::Parameters to Python dict
py::dict pitchShifterParamsToDict(const PitchShifterProcessor::Parameters& params) {
    py::dict d;
    d["pitch_l"] = params.pitchL;
    d["pitch_r"] = params.pitchR;
    d["delay_l"] = params.delayL;
    d["delay_r"] = params.delayR;
    d["feedback"] = params.feedback;
    d["mix"] = params.mix;
    d["spread"] = params.spread;
    d["preset"] = pitchPresetToString(params.preset);
    d["bypass"] = params.bypass;
    return d;
}

// Convert Python dict to PitchShifterProcessor::Parameters
PitchShifterProcessor::Parameters dictToPitchShifterParams(const py::dict& d) {
    PitchShifterProcessor::Parameters params;
    if (d.contains("pitch_l")) params.pitchL = d["pitch_l"].cast<float>();
    if (d.contains("pitch_r")) params.pitchR = d["pitch_r"].cast<float>();
    if (d.contains("delay_l")) params.delayL = d["delay_l"].cast<float>();
    if (d.contains("delay_r")) params.delayR = d["delay_r"].cast<float>();
    if (d.contains("feedback")) params.feedback = d["feedback"].cast<float>();
    if (d.contains("mix")) params.mix = d["mix"].cast<float>();
    if (d.contains("spread")) params.spread = d["spread"].cast<float>();
    if (d.contains("preset")) params.preset = stringToPitchPreset(d["preset"].cast<std::string>());
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

// Convert PitchShifterProcessor::Metering to Python dict
py::dict pitchShifterMeteringToDict(const PitchShifterProcessor::Metering& m) {
    py::dict d;
    d["input_level_l"] = m.inputLevelL;
    d["input_level_r"] = m.inputLevelR;
    d["output_level_l"] = m.outputLevelL;
    d["output_level_r"] = m.outputLevelR;
    d["grain_phase"] = m.grainPhase;
    return d;
}

// Convert PitchShifterProcessor::PresetInfo to Python dict
py::dict pitchPresetInfoToDict(const PitchShifterProcessor::PresetInfo& info) {
    py::dict d;
    d["name"] = info.name ? std::string(info.name) : "";
    d["song"] = info.song ? std::string(info.song) : "";
    d["album"] = info.album ? std::string(info.album) : "";
    d["year"] = info.year ? std::string(info.year) : "";
    d["description"] = info.description ? std::string(info.description) : "";
    return d;
}

// ========================================
// IntelliFX 8-Voice Chorus Type Converters
// ========================================

// Convert IntelliFX8VoiceChorusProcessor::VoiceParameters to Python dict
py::dict intellifxVoiceParamsToDict(const IntelliFX8VoiceChorusProcessor::VoiceParameters& params) {
    py::dict d;
    d["level"] = params.level;
    d["pan"] = params.pan;
    d["delay"] = params.delay;
    d["depth"] = params.depth;
    d["rate"] = params.rate;
    return d;
}

// Convert Python dict to IntelliFX8VoiceChorusProcessor::VoiceParameters
IntelliFX8VoiceChorusProcessor::VoiceParameters dictToIntelliFXVoiceParams(const py::dict& d) {
    IntelliFX8VoiceChorusProcessor::VoiceParameters params;
    if (d.contains("level")) params.level = d["level"].cast<float>();
    if (d.contains("pan")) params.pan = d["pan"].cast<float>();
    if (d.contains("delay")) params.delay = d["delay"].cast<float>();
    if (d.contains("depth")) params.depth = d["depth"].cast<float>();
    if (d.contains("rate")) params.rate = d["rate"].cast<float>();
    return params;
}

// Convert IntelliFX8VoiceChorusProcessor::HushParameters to Python dict
py::dict intellifxHushParamsToDict(const IntelliFX8VoiceChorusProcessor::HushParameters& params) {
    py::dict d;
    d["enabled"] = params.enabled;
    d["threshold"] = params.threshold;
    d["release_rate"] = params.releaseRate;
    return d;
}

// Convert Python dict to IntelliFX8VoiceChorusProcessor::HushParameters
IntelliFX8VoiceChorusProcessor::HushParameters dictToIntelliFXHushParams(const py::dict& d) {
    IntelliFX8VoiceChorusProcessor::HushParameters params;
    if (d.contains("enabled")) params.enabled = d["enabled"].cast<bool>();
    if (d.contains("threshold")) params.threshold = d["threshold"].cast<float>();
    if (d.contains("release_rate")) params.releaseRate = d["release_rate"].cast<float>();
    return params;
}

// Convert IntelliFX8VoiceChorusProcessor::Parameters to Python dict
py::dict intellifxParamsToDict(const IntelliFX8VoiceChorusProcessor::Parameters& params) {
    py::dict d;

    // Voice parameters array
    py::list voices;
    for (int i = 0; i < IntelliFX8VoiceChorusProcessor::NUM_VOICES; ++i) {
        voices.append(intellifxVoiceParamsToDict(params.voices[i]));
    }
    d["voices"] = voices;

    // Global mixer
    d["chorus_level"] = params.chorusLevel;
    d["direct_level_l"] = params.directLevelL;
    d["direct_level_r"] = params.directLevelR;
    d["regen_l"] = params.regenL;
    d["regen_r"] = params.regenR;

    // HUSH
    d["hush"] = intellifxHushParamsToDict(params.hush);

    // Master
    d["bypass"] = params.bypass;

    return d;
}

// Convert Python dict to IntelliFX8VoiceChorusProcessor::Parameters
IntelliFX8VoiceChorusProcessor::Parameters dictToIntelliFXParams(const py::dict& d) {
    IntelliFX8VoiceChorusProcessor::Parameters params;

    if (d.contains("voices")) {
        auto voicesList = d["voices"].cast<py::list>();
        for (size_t i = 0; i < std::min(static_cast<size_t>(IntelliFX8VoiceChorusProcessor::NUM_VOICES),
                                        voicesList.size()); ++i) {
            params.voices[i] = dictToIntelliFXVoiceParams(voicesList[i].cast<py::dict>());
        }
    }

    if (d.contains("chorus_level")) params.chorusLevel = d["chorus_level"].cast<float>();
    if (d.contains("direct_level_l")) params.directLevelL = d["direct_level_l"].cast<float>();
    if (d.contains("direct_level_r")) params.directLevelR = d["direct_level_r"].cast<float>();
    if (d.contains("regen_l")) params.regenL = d["regen_l"].cast<float>();
    if (d.contains("regen_r")) params.regenR = d["regen_r"].cast<float>();
    if (d.contains("hush")) params.hush = dictToIntelliFXHushParams(d["hush"].cast<py::dict>());
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();

    return params;
}

// Convert IntelliFX8VoiceChorusProcessor::Metering to Python dict
py::dict intellifxMeteringToDict(const IntelliFX8VoiceChorusProcessor::Metering& m) {
    py::dict d;
    d["input_level_l"] = m.inputLevelL;
    d["input_level_r"] = m.inputLevelR;
    d["output_level_l"] = m.outputLevelL;
    d["output_level_r"] = m.outputLevelR;
    d["chorus_level_l"] = m.chorusLevelL;
    d["chorus_level_r"] = m.chorusLevelR;
    d["hush_gain_reduction"] = m.hushGainReduction;

    py::list lfoPhases;
    for (int i = 0; i < IntelliFX8VoiceChorusProcessor::NUM_VOICES; ++i) {
        lfoPhases.append(m.voiceLfoPhases[i]);
    }
    d["voice_lfo_phases"] = lfoPhases;

    return d;
}

// Convert IntelliFX8VoiceChorusProcessor::PresetInfo to Python dict
py::dict intellifxPresetInfoToDict(const IntelliFX8VoiceChorusProcessor::PresetInfo& info) {
    py::dict d;
    d["index"] = info.index;
    d["name"] = info.name ? std::string(info.name) : "";
    d["category"] = info.category ? std::string(info.category) : "";
    d["description"] = info.description ? std::string(info.description) : "";
    return d;
}

// ========================================
// Boss XS-1 Poly Shifter Type Converters
// ========================================

// Convert BossXS1PolyShifterProcessor::Preset to string
std::string bossXS1PresetToString(BossXS1PolyShifterProcessor::Preset preset) {
    switch (preset) {
        case BossXS1PolyShifterProcessor::Preset::Manual: return "manual";
        case BossXS1PolyShifterProcessor::Preset::DropD: return "drop_d";
        case BossXS1PolyShifterProcessor::Preset::DropDSharp: return "drop_d_sharp";
        case BossXS1PolyShifterProcessor::Preset::HalfStepDown: return "half_step_down";
        case BossXS1PolyShifterProcessor::Preset::Capo2ndFret: return "capo_2nd_fret";
        case BossXS1PolyShifterProcessor::Preset::Capo3rdFret: return "capo_3rd_fret";
        case BossXS1PolyShifterProcessor::Preset::Capo5thFret: return "capo_5th_fret";
        case BossXS1PolyShifterProcessor::Preset::OctaveUp: return "octave_up";
        case BossXS1PolyShifterProcessor::Preset::OctaveDown: return "octave_down";
        case BossXS1PolyShifterProcessor::Preset::OctaveUpDown: return "octave_up_down";
        case BossXS1PolyShifterProcessor::Preset::MicroPitchWide: return "micro_pitch_wide";
        case BossXS1PolyShifterProcessor::Preset::MicroPitchNarrow: return "micro_pitch_narrow";
        case BossXS1PolyShifterProcessor::Preset::VoiceDoubling: return "voice_doubling";
        case BossXS1PolyShifterProcessor::Preset::StringDoubling: return "string_doubling";
        case BossXS1PolyShifterProcessor::Preset::PianistOctaves: return "pianist_octaves";
        case BossXS1PolyShifterProcessor::Preset::SubBass: return "sub_bass";
        case BossXS1PolyShifterProcessor::Preset::SonicScreamer: return "sonic_screamer";
        case BossXS1PolyShifterProcessor::Preset::UniqueIntervals: return "unique_intervals";
        case BossXS1PolyShifterProcessor::Preset::MinorThird: return "minor_third";
        case BossXS1PolyShifterProcessor::Preset::ChordShift: return "chord_shift";
        case BossXS1PolyShifterProcessor::Preset::DetuneChorus: return "detune_chorus";
        case BossXS1PolyShifterProcessor::Preset::SpaceyVibrato: return "spacey_vibrato";
        case BossXS1PolyShifterProcessor::Preset::RoboticMod: return "robotic_mod";
        default: return "manual";
    }
}

// Convert string to BossXS1PolyShifterProcessor::Preset
BossXS1PolyShifterProcessor::Preset stringToBossXS1Preset(const std::string& str) {
    if (str == "drop_d") return BossXS1PolyShifterProcessor::Preset::DropD;
    if (str == "drop_d_sharp") return BossXS1PolyShifterProcessor::Preset::DropDSharp;
    if (str == "half_step_down") return BossXS1PolyShifterProcessor::Preset::HalfStepDown;
    if (str == "capo_2nd_fret") return BossXS1PolyShifterProcessor::Preset::Capo2ndFret;
    if (str == "capo_3rd_fret") return BossXS1PolyShifterProcessor::Preset::Capo3rdFret;
    if (str == "capo_5th_fret") return BossXS1PolyShifterProcessor::Preset::Capo5thFret;
    if (str == "octave_up") return BossXS1PolyShifterProcessor::Preset::OctaveUp;
    if (str == "octave_down") return BossXS1PolyShifterProcessor::Preset::OctaveDown;
    if (str == "octave_up_down") return BossXS1PolyShifterProcessor::Preset::OctaveUpDown;
    if (str == "micro_pitch_wide") return BossXS1PolyShifterProcessor::Preset::MicroPitchWide;
    if (str == "micro_pitch_narrow") return BossXS1PolyShifterProcessor::Preset::MicroPitchNarrow;
    if (str == "voice_doubling") return BossXS1PolyShifterProcessor::Preset::VoiceDoubling;
    if (str == "string_doubling") return BossXS1PolyShifterProcessor::Preset::StringDoubling;
    if (str == "pianist_octaves") return BossXS1PolyShifterProcessor::Preset::PianistOctaves;
    if (str == "sub_bass") return BossXS1PolyShifterProcessor::Preset::SubBass;
    if (str == "sonic_screamer") return BossXS1PolyShifterProcessor::Preset::SonicScreamer;
    if (str == "unique_intervals") return BossXS1PolyShifterProcessor::Preset::UniqueIntervals;
    if (str == "minor_third") return BossXS1PolyShifterProcessor::Preset::MinorThird;
    if (str == "chord_shift") return BossXS1PolyShifterProcessor::Preset::ChordShift;
    if (str == "detune_chorus") return BossXS1PolyShifterProcessor::Preset::DetuneChorus;
    if (str == "spacey_vibrato") return BossXS1PolyShifterProcessor::Preset::SpaceyVibrato;
    if (str == "robotic_mod") return BossXS1PolyShifterProcessor::Preset::RoboticMod;
    return BossXS1PolyShifterProcessor::Preset::Manual;
}

// Convert BossXS1PolyShifterProcessor::Parameters to Python dict
py::dict bossXS1ParamsToDict(const BossXS1PolyShifterProcessor::Parameters& params) {
    py::dict d;
    d["shift_amount"] = params.shiftAmount;
    d["balance"] = params.balance;
    d["shift_direction"] = params.shiftDirection;
    d["detune_mode"] = params.detuneMode;
    d["pedal_momentary"] = params.pedalMomentary;
    d["pedal_position"] = params.pedalPosition;
    d["pedal_min"] = params.pedalMin;
    d["pedal_max"] = params.pedalMax;
    d["pedal_enabled"] = params.pedalEnabled;
    d["detune_amount"] = params.detuneAmount;
    d["glide"] = params.glide;
    d["feedback"] = params.feedback;
    d["preset"] = bossXS1PresetToString(params.preset);
    d["bypass"] = params.bypass;
    d["active"] = params.active;
    return d;
}

// Convert Python dict to BossXS1PolyShifterProcessor::Parameters
BossXS1PolyShifterProcessor::Parameters dictToBossXS1Params(const py::dict& d) {
    BossXS1PolyShifterProcessor::Parameters params;
    if (d.contains("shift_amount")) params.shiftAmount = d["shift_amount"].cast<float>();
    if (d.contains("balance")) params.balance = d["balance"].cast<float>();
    if (d.contains("shift_direction")) params.shiftDirection = d["shift_direction"].cast<int>();
    if (d.contains("detune_mode")) params.detuneMode = d["detune_mode"].cast<bool>();
    if (d.contains("pedal_momentary")) params.pedalMomentary = d["pedal_momentary"].cast<bool>();
    if (d.contains("pedal_position")) params.pedalPosition = d["pedal_position"].cast<float>();
    if (d.contains("pedal_min")) params.pedalMin = d["pedal_min"].cast<float>();
    if (d.contains("pedal_max")) params.pedalMax = d["pedal_max"].cast<float>();
    if (d.contains("pedal_enabled")) params.pedalEnabled = d["pedal_enabled"].cast<bool>();
    if (d.contains("detune_amount")) params.detuneAmount = d["detune_amount"].cast<float>();
    if (d.contains("glide")) params.glide = d["glide"].cast<float>();
    if (d.contains("feedback")) params.feedback = d["feedback"].cast<float>();
    if (d.contains("preset")) params.preset = stringToBossXS1Preset(d["preset"].cast<std::string>());
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    if (d.contains("active")) params.active = d["active"].cast<bool>();
    return params;
}

// ========================================
// ShoeGaze Type Converters
// ========================================

// Convert ShoeGazeProcessor::Preset to string
std::string shoegazePresetToString(ShoeGazeProcessor::Preset preset) {
    switch (preset) {
        case ShoeGazeProcessor::Preset::Manual: return "manual";
        case ShoeGazeProcessor::Preset::Loveless: return "loveless";
        case ShoeGazeProcessor::Preset::Souvlaki: return "souvlaki";
        case ShoeGazeProcessor::Preset::Treasure: return "treasure";
        case ShoeGazeProcessor::Preset::SpaceAge: return "space_age";
        case ShoeGazeProcessor::Preset::Psychocandy: return "psychocandy";
        case ShoeGazeProcessor::Preset::Nowhere: return "nowhere";
        default: return "manual";
    }
}

// Convert string to ShoeGazeProcessor::Preset
ShoeGazeProcessor::Preset stringToShoegazePreset(const std::string& str) {
    if (str == "loveless") return ShoeGazeProcessor::Preset::Loveless;
    if (str == "souvlaki") return ShoeGazeProcessor::Preset::Souvlaki;
    if (str == "treasure") return ShoeGazeProcessor::Preset::Treasure;
    if (str == "space_age") return ShoeGazeProcessor::Preset::SpaceAge;
    if (str == "psychocandy") return ShoeGazeProcessor::Preset::Psychocandy;
    if (str == "nowhere") return ShoeGazeProcessor::Preset::Nowhere;
    return ShoeGazeProcessor::Preset::Manual;
}

// Convert ShoeGazeProcessor::Parameters to Python dict
py::dict shoegazeParamsToDict(const ShoeGazeProcessor::Parameters& params) {
    py::dict d;
    // Primary controls
    d["atmosphere"] = params.atmosphere;
    d["decay"] = params.decay;
    d["shimmer"] = params.shimmer;
    d["shimmer_pitch"] = params.shimmerPitch;
    d["modulation"] = params.modulation;
    d["mod_rate"] = params.modRate;
    d["drive"] = params.drive;
    d["delay_time"] = params.delayTime;
    d["delay_feedback"] = params.delayFeedback;
    d["delay_mod"] = params.delayMod;
    d["low_cut"] = params.lowCut;
    d["high_cut"] = params.highCut;
    d["mix"] = params.mix;
    d["stereo_width"] = params.stereoWidth;
    // Advanced controls
    d["reverb_diffusion"] = params.reverbDiffusion;
    d["reverb_damping"] = params.reverbDamping;
    d["reverb_size"] = params.reverbSize;
    d["reverb_mod_depth"] = params.reverbModDepth;
    d["shimmer_feedback"] = params.shimmerFeedback;
    d["shimmer_delay"] = params.shimmerDelay;
    d["chorus_voices"] = params.chorusVoices;
    d["chorus_spread"] = params.chorusSpread;
    d["saturation_tone"] = params.saturationTone;
    d["ducking"] = params.ducking;
    // State
    d["preset"] = shoegazePresetToString(params.preset);
    d["spillover"] = params.spillover;
    d["bypass"] = params.bypass;
    return d;
}

// Convert Python dict to ShoeGazeProcessor::Parameters
ShoeGazeProcessor::Parameters dictToShoegazeParams(const py::dict& d) {
    ShoeGazeProcessor::Parameters params;
    // Primary controls
    if (d.contains("atmosphere")) params.atmosphere = d["atmosphere"].cast<float>();
    if (d.contains("decay")) params.decay = d["decay"].cast<float>();
    if (d.contains("shimmer")) params.shimmer = d["shimmer"].cast<float>();
    if (d.contains("shimmer_pitch")) params.shimmerPitch = d["shimmer_pitch"].cast<float>();
    if (d.contains("modulation")) params.modulation = d["modulation"].cast<float>();
    if (d.contains("mod_rate")) params.modRate = d["mod_rate"].cast<float>();
    if (d.contains("drive")) params.drive = d["drive"].cast<float>();
    if (d.contains("delay_time")) params.delayTime = d["delay_time"].cast<float>();
    if (d.contains("delay_feedback")) params.delayFeedback = d["delay_feedback"].cast<float>();
    if (d.contains("delay_mod")) params.delayMod = d["delay_mod"].cast<float>();
    if (d.contains("low_cut")) params.lowCut = d["low_cut"].cast<float>();
    if (d.contains("high_cut")) params.highCut = d["high_cut"].cast<float>();
    if (d.contains("mix")) params.mix = d["mix"].cast<float>();
    if (d.contains("stereo_width")) params.stereoWidth = d["stereo_width"].cast<float>();
    // Advanced controls
    if (d.contains("reverb_diffusion")) params.reverbDiffusion = d["reverb_diffusion"].cast<float>();
    if (d.contains("reverb_damping")) params.reverbDamping = d["reverb_damping"].cast<float>();
    if (d.contains("reverb_size")) params.reverbSize = d["reverb_size"].cast<float>();
    if (d.contains("reverb_mod_depth")) params.reverbModDepth = d["reverb_mod_depth"].cast<float>();
    if (d.contains("shimmer_feedback")) params.shimmerFeedback = d["shimmer_feedback"].cast<float>();
    if (d.contains("shimmer_delay")) params.shimmerDelay = d["shimmer_delay"].cast<float>();
    if (d.contains("chorus_voices")) params.chorusVoices = d["chorus_voices"].cast<int>();
    if (d.contains("chorus_spread")) params.chorusSpread = d["chorus_spread"].cast<float>();
    if (d.contains("saturation_tone")) params.saturationTone = d["saturation_tone"].cast<float>();
    if (d.contains("ducking")) params.ducking = d["ducking"].cast<float>();
    // State
    if (d.contains("preset")) params.preset = stringToShoegazePreset(d["preset"].cast<std::string>());
    if (d.contains("spillover")) params.spillover = d["spillover"].cast<bool>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

// Convert ShoeGazeProcessor::Metering to Python dict
py::dict shoegazeMeteringToDict(const ShoeGazeProcessor::Metering& m) {
    py::dict d;
    d["input_level_l"] = m.inputLevelL;
    d["input_level_r"] = m.inputLevelR;
    d["output_level_l"] = m.outputLevelL;
    d["output_level_r"] = m.outputLevelR;
    d["reverb_level_l"] = m.reverbLevelL;
    d["reverb_level_r"] = m.reverbLevelR;
    d["shimmer_level"] = m.shimmerLevel;
    d["saturation_amount"] = m.saturationAmount;
    d["chorus_lfo_phase"] = m.chorusLfoPhase;
    d["delay_mod_phase"] = m.delayModPhase;
    d["ducking_gain"] = m.duckingGain;
    return d;
}

// Convert ShoeGazeProcessor::PresetInfo to Python dict
py::dict shoegazePresetInfoToDict(const ShoeGazeProcessor::PresetInfo& info) {
    py::dict d;
    d["name"] = info.name ? std::string(info.name) : "";
    d["artist"] = info.artist ? std::string(info.artist) : "";
    d["description"] = info.description ? std::string(info.description) : "";
    return d;
}

// ========================================
// LexiLove Type Converters
// ========================================

// Convert LexiLoveProcessor::Algorithm to string
std::string lexiAlgorithmToString(LexiLoveProcessor::Algorithm algorithm) {
    switch (algorithm) {
        case LexiLoveProcessor::Algorithm::TiledRoom: return "tiled_room";
        case LexiLoveProcessor::Algorithm::RichPlate: return "rich_plate";
        case LexiLoveProcessor::Algorithm::ConcertHall: return "concert_hall";
        case LexiLoveProcessor::Algorithm::SmallRoom: return "small_room";
        case LexiLoveProcessor::Algorithm::RichChamber: return "rich_chamber";
        case LexiLoveProcessor::Algorithm::Gymnasium: return "gymnasium";
        case LexiLoveProcessor::Algorithm::LongHall: return "long_hall";
        case LexiLoveProcessor::Algorithm::GatedPlate: return "gated_plate";
        case LexiLoveProcessor::Algorithm::Infinite: return "infinite";
        default: return "rich_plate";
    }
}

// Convert string to LexiLoveProcessor::Algorithm
LexiLoveProcessor::Algorithm stringToLexiAlgorithm(const std::string& str) {
    if (str == "tiled_room") return LexiLoveProcessor::Algorithm::TiledRoom;
    if (str == "rich_plate") return LexiLoveProcessor::Algorithm::RichPlate;
    if (str == "concert_hall") return LexiLoveProcessor::Algorithm::ConcertHall;
    if (str == "small_room") return LexiLoveProcessor::Algorithm::SmallRoom;
    if (str == "rich_chamber") return LexiLoveProcessor::Algorithm::RichChamber;
    if (str == "gymnasium") return LexiLoveProcessor::Algorithm::Gymnasium;
    if (str == "long_hall") return LexiLoveProcessor::Algorithm::LongHall;
    if (str == "gated_plate") return LexiLoveProcessor::Algorithm::GatedPlate;
    if (str == "infinite") return LexiLoveProcessor::Algorithm::Infinite;
    return LexiLoveProcessor::Algorithm::RichPlate;
}

// Convert LexiLoveProcessor::Parameters to Python dict
py::dict lexiParamsToDict(const LexiLoveProcessor::Parameters& params) {
    py::dict d;
    d["algorithm"] = lexiAlgorithmToString(params.algorithm);
    d["algorithm_index"] = static_cast<int>(params.algorithm);
    d["pre_delay"] = params.preDelay;
    d["decay_time"] = params.decayTime;
    d["diffusion"] = params.diffusion;
    d["low_decay_mult"] = params.lowDecayMult;
    d["high_decay_mult"] = params.highDecayMult;
    d["low_crossover"] = params.lowCrossover;
    d["high_crossover"] = params.highCrossover;
    d["early_level"] = params.earlyLevel;
    d["early_pattern"] = params.earlyPattern;
    d["mod_depth"] = params.modDepth;
    d["mod_rate"] = params.modRate;
    d["mix"] = params.mix;
    d["high_cut"] = params.highCut;
    d["low_cut"] = params.lowCut;
    d["bypass"] = params.bypass;
    d["spillover"] = params.spillover;
    return d;
}

// Convert Python dict to LexiLoveProcessor::Parameters
LexiLoveProcessor::Parameters dictToLexiParams(const py::dict& d) {
    LexiLoveProcessor::Parameters params;
    if (d.contains("algorithm")) params.algorithm = stringToLexiAlgorithm(d["algorithm"].cast<std::string>());
    if (d.contains("algorithm_index")) params.algorithm = static_cast<LexiLoveProcessor::Algorithm>(d["algorithm_index"].cast<int>());
    if (d.contains("pre_delay")) params.preDelay = d["pre_delay"].cast<float>();
    if (d.contains("decay_time")) params.decayTime = d["decay_time"].cast<float>();
    if (d.contains("diffusion")) params.diffusion = d["diffusion"].cast<float>();
    if (d.contains("low_decay_mult")) params.lowDecayMult = d["low_decay_mult"].cast<float>();
    if (d.contains("high_decay_mult")) params.highDecayMult = d["high_decay_mult"].cast<float>();
    if (d.contains("low_crossover")) params.lowCrossover = d["low_crossover"].cast<float>();
    if (d.contains("high_crossover")) params.highCrossover = d["high_crossover"].cast<float>();
    if (d.contains("early_level")) params.earlyLevel = d["early_level"].cast<float>();
    if (d.contains("early_pattern")) params.earlyPattern = d["early_pattern"].cast<float>();
    if (d.contains("mod_depth")) params.modDepth = d["mod_depth"].cast<float>();
    if (d.contains("mod_rate")) params.modRate = d["mod_rate"].cast<float>();
    if (d.contains("mix")) params.mix = d["mix"].cast<float>();
    if (d.contains("high_cut")) params.highCut = d["high_cut"].cast<float>();
    if (d.contains("low_cut")) params.lowCut = d["low_cut"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    if (d.contains("spillover")) params.spillover = d["spillover"].cast<bool>();
    return params;
}

// Convert LexiLoveProcessor::Metering to Python dict
py::dict lexiMeteringToDict(const LexiLoveProcessor::Metering& m) {
    py::dict d;
    d["input_level_l"] = m.inputLevelL;
    d["input_level_r"] = m.inputLevelR;
    d["output_level_l"] = m.outputLevelL;
    d["output_level_r"] = m.outputLevelR;
    d["reverb_level_l"] = m.reverbLevelL;
    d["reverb_level_r"] = m.reverbLevelR;
    d["early_level"] = m.earlyLevel;
    d["late_level"] = m.lateLevel;
    d["mod_lfo_phase"] = m.modLfoPhase;
    d["current_decay"] = m.currentDecay;
    return d;
}

// Convert LexiLoveProcessor::AlgorithmInfo to Python dict
py::dict lexiAlgorithmInfoToDict(const LexiLoveProcessor::AlgorithmInfo& info) {
    py::dict d;
    d["name"] = info.name ? std::string(info.name) : "";
    d["short_name"] = info.shortName ? std::string(info.shortName) : "";
    d["description"] = info.description ? std::string(info.description) : "";
    return d;
}

// ========================================
// H3000 Harmonizer Type Converters
// ========================================

// Convert H3000Processor::Algorithm to string
std::string h3000AlgorithmToString(H3000Processor::Algorithm algorithm) {
    switch (algorithm) {
        case H3000Processor::Algorithm::Micropitch: return "micropitch";
        case H3000Processor::Algorithm::DualShift: return "dual_shift";
        case H3000Processor::Algorithm::CrystalEchoes: return "crystal_echoes";
        case H3000Processor::Algorithm::StereoShift: return "stereo_shift";
        case H3000Processor::Algorithm::LayeredShift: return "layered_shift";
        case H3000Processor::Algorithm::SweptCombs: return "swept_combs";
        case H3000Processor::Algorithm::StutterShift: return "stutter_shift";
        case H3000Processor::Algorithm::ReversePitch: return "reverse_pitch";
        case H3000Processor::Algorithm::BandDelays: return "band_delays";
        case H3000Processor::Algorithm::PatchFactory: return "patch_factory";
        default: return "micropitch";
    }
}

// Convert string to H3000Processor::Algorithm
H3000Processor::Algorithm stringToH3000Algorithm(const std::string& str) {
    if (str == "micropitch") return H3000Processor::Algorithm::Micropitch;
    if (str == "dual_shift") return H3000Processor::Algorithm::DualShift;
    if (str == "crystal_echoes") return H3000Processor::Algorithm::CrystalEchoes;
    if (str == "stereo_shift") return H3000Processor::Algorithm::StereoShift;
    if (str == "layered_shift") return H3000Processor::Algorithm::LayeredShift;
    if (str == "swept_combs") return H3000Processor::Algorithm::SweptCombs;
    if (str == "stutter_shift") return H3000Processor::Algorithm::StutterShift;
    if (str == "reverse_pitch") return H3000Processor::Algorithm::ReversePitch;
    if (str == "band_delays") return H3000Processor::Algorithm::BandDelays;
    if (str == "patch_factory") return H3000Processor::Algorithm::PatchFactory;
    return H3000Processor::Algorithm::Micropitch;
}

// Convert H3000Processor::Parameters to Python dict
py::dict h3000ParamsToDict(const H3000Processor::Parameters& params) {
    py::dict d;
    d["algorithm"] = h3000AlgorithmToString(static_cast<H3000Processor::Algorithm>(params.algorithm));
    d["algorithm_index"] = params.algorithm;
    d["pitch_l"] = params.pitchL;
    d["pitch_r"] = params.pitchR;
    d["delay_l"] = params.delayL;
    d["delay_r"] = params.delayR;
    d["feedback"] = params.feedback;
    d["cross_feedback"] = params.crossFeedback;
    d["mod_depth"] = params.modDepth;
    d["mod_rate"] = params.modRate;
    d["low_cut"] = params.lowCut;
    d["high_cut"] = params.highCut;
    d["mix"] = params.mix;
    d["level_l"] = params.levelL;
    d["level_r"] = params.levelR;
    d["bypass"] = params.bypass;
    d["glide"] = params.glide;
    return d;
}

// Convert Python dict to H3000Processor::Parameters
H3000Processor::Parameters dictToH3000Params(const py::dict& d) {
    H3000Processor::Parameters params;
    if (d.contains("algorithm")) params.algorithm = static_cast<int>(stringToH3000Algorithm(d["algorithm"].cast<std::string>()));
    if (d.contains("algorithm_index")) params.algorithm = d["algorithm_index"].cast<int>();
    if (d.contains("pitch_l")) params.pitchL = d["pitch_l"].cast<float>();
    if (d.contains("pitch_r")) params.pitchR = d["pitch_r"].cast<float>();
    if (d.contains("delay_l")) params.delayL = d["delay_l"].cast<float>();
    if (d.contains("delay_r")) params.delayR = d["delay_r"].cast<float>();
    if (d.contains("feedback")) params.feedback = d["feedback"].cast<float>();
    if (d.contains("cross_feedback")) params.crossFeedback = d["cross_feedback"].cast<float>();
    if (d.contains("mod_depth")) params.modDepth = d["mod_depth"].cast<float>();
    if (d.contains("mod_rate")) params.modRate = d["mod_rate"].cast<float>();
    if (d.contains("low_cut")) params.lowCut = d["low_cut"].cast<float>();
    if (d.contains("high_cut")) params.highCut = d["high_cut"].cast<float>();
    if (d.contains("mix")) params.mix = d["mix"].cast<float>();
    if (d.contains("level_l")) params.levelL = d["level_l"].cast<float>();
    if (d.contains("level_r")) params.levelR = d["level_r"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    if (d.contains("glide")) params.glide = d["glide"].cast<float>();
    return params;
}

// Convert H3000Processor::Metering to Python dict
py::dict h3000MeteringToDict(const H3000Processor::Metering& m) {
    py::dict d;
    d["input_level_l"] = m.inputLevelL;
    d["input_level_r"] = m.inputLevelR;
    d["output_level_l"] = m.outputLevelL;
    d["output_level_r"] = m.outputLevelR;
    d["pitch_l_actual"] = m.pitchLActual;
    d["pitch_r_actual"] = m.pitchRActual;
    d["delay_l_actual"] = m.delayLActual;
    d["delay_r_actual"] = m.delayRActual;
    d["mod_phase"] = m.modPhase;
    return d;
}

// Convert H3000Processor::AlgorithmInfo to Python dict
py::dict h3000AlgorithmInfoToDict(const H3000Processor::AlgorithmInfo& info) {
    py::dict d;
    d["name"] = info.name ? std::string(info.name) : "";
    d["short_name"] = info.shortName ? std::string(info.shortName) : "";
    d["description"] = info.description ? std::string(info.description) : "";
    return d;
}

// ========================================
// Peavey 5150 Converters
// ========================================

std::string peavey5150PresetToString(Peavey5150Processor::Preset preset) {
    switch (preset) {
        case Peavey5150Processor::Preset::Manual: return "manual";
        case Peavey5150Processor::Preset::BrownSound: return "brown_sound";
        case Peavey5150Processor::Preset::PanteraScoop: return "pantera_scoop";
        case Peavey5150Processor::Preset::ModernMetal: return "modern_metal";
        case Peavey5150Processor::Preset::HardRock: return "hard_rock";
        case Peavey5150Processor::Preset::Crunch: return "crunch";
        default: return "manual";
    }
}

Peavey5150Processor::Preset stringToPeavey5150Preset(const std::string& str) {
    if (str == "brown_sound") return Peavey5150Processor::Preset::BrownSound;
    if (str == "pantera_scoop") return Peavey5150Processor::Preset::PanteraScoop;
    if (str == "modern_metal") return Peavey5150Processor::Preset::ModernMetal;
    if (str == "hard_rock") return Peavey5150Processor::Preset::HardRock;
    if (str == "crunch") return Peavey5150Processor::Preset::Crunch;
    return Peavey5150Processor::Preset::Manual;
}

py::dict peavey5150ParamsToDict(const Peavey5150Processor::Parameters& params) {
    py::dict d;
    d["pre_gain"] = params.preGain;
    d["post_gain"] = params.postGain;
    d["low"] = params.low;
    d["mid"] = params.mid;
    d["high"] = params.high;
    d["presence"] = params.presence;
    d["resonance"] = params.resonance;
    d["bright"] = params.bright;
    d["bias"] = params.bias;
    d["preset"] = static_cast<int>(params.preset);
    d["preset_name"] = peavey5150PresetToString(params.preset);
    d["bypass"] = params.bypass;
    return d;
}

Peavey5150Processor::Parameters dictToPeavey5150Params(const py::dict& d) {
    Peavey5150Processor::Parameters params;
    if (d.contains("pre_gain")) params.preGain = d["pre_gain"].cast<float>();
    if (d.contains("post_gain")) params.postGain = d["post_gain"].cast<float>();
    if (d.contains("low")) params.low = d["low"].cast<float>();
    if (d.contains("mid")) params.mid = d["mid"].cast<float>();
    if (d.contains("high")) params.high = d["high"].cast<float>();
    if (d.contains("presence")) params.presence = d["presence"].cast<float>();
    if (d.contains("resonance")) params.resonance = d["resonance"].cast<float>();
    if (d.contains("bright")) params.bright = d["bright"].cast<bool>();
    if (d.contains("bias")) params.bias = d["bias"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

py::dict peavey5150MeteringToDict(const Peavey5150Processor::Metering& m) {
    py::dict d;
    d["input_level"] = m.inputLevel;
    d["output_level"] = m.outputLevel;
    d["preamp_level"] = m.preampLevel;
    d["power_level"] = m.powerLevel;
    d["supply_sag"] = m.supplySag;
    d["cpu_load"] = m.cpuLoad;
    return d;
}

// ========================================
// Tweed Bassman 5F6-A Converters
// ========================================

std::string tweedBassmanPresetToString(TweedBassmanProcessor::Preset preset) {
    switch (preset) {
        case TweedBassmanProcessor::Preset::Manual: return "manual";
        case TweedBassmanProcessor::Preset::Stock5F6A: return "stock_5f6a";
        case TweedBassmanProcessor::Preset::CrankedTweed: return "cranked_tweed";
        case TweedBassmanProcessor::Preset::BluesBreakup: return "blues_breakup";
        case TweedBassmanProcessor::Preset::CountryClean: return "country_clean";
        case TweedBassmanProcessor::Preset::JumpedDirty: return "jumped_dirty";
        case TweedBassmanProcessor::Preset::HighGainMod: return "high_gain_mod";
        case TweedBassmanProcessor::Preset::NeilYoung: return "neil_young";
        case TweedBassmanProcessor::Preset::TweedDeluxe: return "tweed_deluxe";
        case TweedBassmanProcessor::Preset::JTM45Flavor: return "jtm45_flavor";
        case TweedBassmanProcessor::Preset::SagMonster: return "sag_monster";
        case TweedBassmanProcessor::Preset::PedalPlatform: return "pedal_platform";
        case TweedBassmanProcessor::Preset::BrightChimey: return "bright_chimey";
        case TweedBassmanProcessor::Preset::SRVTone: return "srv_tone";
        case TweedBassmanProcessor::Preset::RecordingDI: return "recording_di";
        default: return "manual";
    }
}

TweedBassmanProcessor::Preset stringToTweedBassmanPreset(const std::string& str) {
    if (str == "stock_5f6a") return TweedBassmanProcessor::Preset::Stock5F6A;
    if (str == "cranked_tweed") return TweedBassmanProcessor::Preset::CrankedTweed;
    if (str == "blues_breakup") return TweedBassmanProcessor::Preset::BluesBreakup;
    if (str == "country_clean") return TweedBassmanProcessor::Preset::CountryClean;
    if (str == "jumped_dirty") return TweedBassmanProcessor::Preset::JumpedDirty;
    if (str == "high_gain_mod") return TweedBassmanProcessor::Preset::HighGainMod;
    if (str == "neil_young") return TweedBassmanProcessor::Preset::NeilYoung;
    if (str == "tweed_deluxe") return TweedBassmanProcessor::Preset::TweedDeluxe;
    if (str == "jtm45_flavor") return TweedBassmanProcessor::Preset::JTM45Flavor;
    if (str == "sag_monster") return TweedBassmanProcessor::Preset::SagMonster;
    if (str == "pedal_platform") return TweedBassmanProcessor::Preset::PedalPlatform;
    if (str == "bright_chimey") return TweedBassmanProcessor::Preset::BrightChimey;
    if (str == "srv_tone") return TweedBassmanProcessor::Preset::SRVTone;
    if (str == "recording_di") return TweedBassmanProcessor::Preset::RecordingDI;
    return TweedBassmanProcessor::Preset::Manual;
}

py::dict tweedBassmanParamsToDict(const TweedBassmanProcessor::Parameters& params) {
    py::dict d;
    d["channel_mode"] = params.channelMode;
    d["normal_volume"] = params.normalVolume;
    d["bright_volume"] = params.brightVolume;
    d["bright_cap"] = params.brightCap;
    d["v1_tube_type"] = params.v1TubeType;
    d["cathode_bypass"] = params.cathodeBypass;
    d["cathode_bias"] = params.cathodeBias;
    d["treble"] = params.treble;
    d["mid"] = params.mid;
    d["bass"] = params.bass;
    d["raw_switch"] = params.rawSwitch;
    d["master_volume"] = params.masterVolume;
    d["presence"] = params.presence;
    d["nfb_mode"] = params.nfbMode;
    d["power_tube_type"] = params.powerTubeType;
    d["bias_mode"] = params.biasMode;
    d["rectifier_type"] = params.rectifierType;
    d["output_level"] = params.outputLevel;
    d["cabinet_enabled"] = params.cabinetEnabled;
    d["cabinet_ir"] = params.cabinetIR;
    d["preset"] = static_cast<int>(params.preset);
    d["preset_name"] = tweedBassmanPresetToString(params.preset);
    d["bypass"] = params.bypass;
    return d;
}

TweedBassmanProcessor::Parameters dictToTweedBassmanParams(const py::dict& d) {
    TweedBassmanProcessor::Parameters params;
    if (d.contains("channel_mode")) params.channelMode = d["channel_mode"].cast<int>();
    if (d.contains("normal_volume")) params.normalVolume = d["normal_volume"].cast<float>();
    if (d.contains("bright_volume")) params.brightVolume = d["bright_volume"].cast<float>();
    if (d.contains("bright_cap")) params.brightCap = d["bright_cap"].cast<bool>();
    if (d.contains("v1_tube_type")) params.v1TubeType = d["v1_tube_type"].cast<int>();
    if (d.contains("cathode_bypass")) params.cathodeBypass = d["cathode_bypass"].cast<bool>();
    if (d.contains("cathode_bias")) params.cathodeBias = d["cathode_bias"].cast<int>();
    if (d.contains("treble")) params.treble = d["treble"].cast<float>();
    if (d.contains("mid")) params.mid = d["mid"].cast<float>();
    if (d.contains("bass")) params.bass = d["bass"].cast<float>();
    if (d.contains("raw_switch")) params.rawSwitch = d["raw_switch"].cast<bool>();
    if (d.contains("master_volume")) params.masterVolume = d["master_volume"].cast<float>();
    if (d.contains("presence")) params.presence = d["presence"].cast<float>();
    if (d.contains("nfb_mode")) params.nfbMode = d["nfb_mode"].cast<int>();
    if (d.contains("power_tube_type")) params.powerTubeType = d["power_tube_type"].cast<int>();
    if (d.contains("bias_mode")) params.biasMode = d["bias_mode"].cast<int>();
    if (d.contains("rectifier_type")) params.rectifierType = d["rectifier_type"].cast<int>();
    if (d.contains("output_level")) params.outputLevel = d["output_level"].cast<float>();
    if (d.contains("cabinet_enabled")) params.cabinetEnabled = d["cabinet_enabled"].cast<bool>();
    if (d.contains("cabinet_ir")) params.cabinetIR = d["cabinet_ir"].cast<int>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

py::dict tweedBassmanMeteringToDict(const TweedBassmanProcessor::Metering& m) {
    py::dict d;
    d["input_level"] = m.inputLevel;
    d["output_level"] = m.outputLevel;
    d["preamp_level"] = m.preampLevel;
    d["power_level"] = m.powerLevel;
    d["supply_sag"] = m.supplySag;
    d["cpu_load"] = m.cpuLoad;
    return d;
}

// ========================================
// PassionFX Multi-Effect Converters
// ========================================

std::string passionfxPresetToString(PassionFXProcessor::Preset preset) {
    switch (preset) {
        case PassionFXProcessor::Preset::Manual: return "manual";
        case PassionFXProcessor::Preset::Liberty: return "liberty";
        case PassionFXProcessor::Preset::EroticNightmares: return "erotic_nightmares";
        case PassionFXProcessor::Preset::TheAnimal: return "the_animal";
        case PassionFXProcessor::Preset::Answers: return "answers";
        case PassionFXProcessor::Preset::TheRiddle: return "the_riddle";
        case PassionFXProcessor::Preset::Ballerina1224: return "ballerina_12_24";
        case PassionFXProcessor::Preset::ForTheLoveOfGod: return "for_the_love_of_god";
        case PassionFXProcessor::Preset::TheAudienceIsListening: return "the_audience_is_listening";
        case PassionFXProcessor::Preset::IWouldLoveTo: return "i_would_love_to";
        case PassionFXProcessor::Preset::BluePowder: return "blue_powder";
        case PassionFXProcessor::Preset::GreasyKidsStuff: return "greasy_kids_stuff";
        case PassionFXProcessor::Preset::AlienWaterKiss: return "alien_water_kiss";
        case PassionFXProcessor::Preset::Sisters: return "sisters";
        case PassionFXProcessor::Preset::LoveSecrets: return "love_secrets";
        default: return "manual";
    }
}

PassionFXProcessor::Preset stringToPassionfxPreset(const std::string& str) {
    if (str == "liberty") return PassionFXProcessor::Preset::Liberty;
    if (str == "erotic_nightmares") return PassionFXProcessor::Preset::EroticNightmares;
    if (str == "the_animal") return PassionFXProcessor::Preset::TheAnimal;
    if (str == "answers") return PassionFXProcessor::Preset::Answers;
    if (str == "the_riddle") return PassionFXProcessor::Preset::TheRiddle;
    if (str == "ballerina_12_24") return PassionFXProcessor::Preset::Ballerina1224;
    if (str == "for_the_love_of_god") return PassionFXProcessor::Preset::ForTheLoveOfGod;
    if (str == "the_audience_is_listening") return PassionFXProcessor::Preset::TheAudienceIsListening;
    if (str == "i_would_love_to") return PassionFXProcessor::Preset::IWouldLoveTo;
    if (str == "blue_powder") return PassionFXProcessor::Preset::BluePowder;
    if (str == "greasy_kids_stuff") return PassionFXProcessor::Preset::GreasyKidsStuff;
    if (str == "alien_water_kiss") return PassionFXProcessor::Preset::AlienWaterKiss;
    if (str == "sisters") return PassionFXProcessor::Preset::Sisters;
    if (str == "love_secrets") return PassionFXProcessor::Preset::LoveSecrets;
    return PassionFXProcessor::Preset::Manual;
}

py::dict passionfxParamsToDict(const PassionFXProcessor::Parameters& params) {
    py::dict d;
    // Gate
    d["gate_enabled"] = params.noiseGateEnabled;
    d["gate_threshold"] = params.noiseGateThreshold;
    d["gate_release"] = params.noiseGateRelease;
    // Comp
    d["comp_enabled"] = params.compressorEnabled;
    d["comp_threshold"] = params.compressorThreshold;
    d["comp_ratio"] = params.compressorRatio;
    d["comp_attack"] = params.compressorAttack;
    d["comp_release"] = params.compressorRelease;
    d["comp_glassy"] = params.compressorGlassy;
    // Wah
    d["wah_enabled"] = params.wahEnabled;
    d["wah_mode"] = params.wahMode;
    d["wah_position"] = params.wahPosition;
    d["wah_q"] = params.wahQ;
    // Phaser
    d["phaser_enabled"] = params.phaserEnabled;
    d["phaser_rate"] = params.phaserRate;
    d["phaser_depth"] = params.phaserDepth;
    d["phaser_stages"] = params.phaserStages;
    d["phaser_feedback"] = params.phaserFeedback;
    // Chorus
    d["chorus_enabled"] = params.chorusEnabled;
    d["chorus_rate"] = params.chorusRate;
    d["chorus_depth"] = params.chorusDepth;
    d["chorus_voices"] = params.chorusVoices;
    d["chorus_mix"] = params.chorusMix;
    // PitchShifter
    d["pitch_enabled"] = params.pitchShifterEnabled;
    d["pitch_semitones"] = params.pitchShifterSemitones;
    d["pitch_mix"] = params.pitchShifterMix;
    // Harmonizer
    d["harm_enabled"] = params.harmonizerEnabled;
    d["harm_voice1_interval"] = params.harmonizerVoice1;
    d["harm_voice2_interval"] = params.harmonizerVoice2;
    d["harm_detune_cents"] = params.harmonizerDetune;
    d["harm_mix"] = params.harmonizerMix;
    // Delay
    d["delay_enabled"] = params.delayEnabled;
    d["delay_time_l"] = params.delayTimeL;
    d["delay_time_r"] = params.delayTimeR;
    d["delay_feedback"] = params.delayFeedback;
    d["delay_mix"] = params.delayMix;
    d["delay_freeze"] = params.delayFreeze;
    d["delay_pitch_shift_l"] = params.delayPitchShiftL;
    d["delay_pitch_shift_r"] = params.delayPitchShiftR;
    // Reverb
    d["reverb_enabled"] = params.reverbEnabled;
    d["reverb_type"] = params.reverbType;
    d["reverb_decay"] = params.reverbDecay;
    d["reverb_shimmer_amount"] = params.reverbShimmerAmount;
    d["reverb_shimmer_interval"] = params.reverbShimmerInterval;
    d["reverb_mix"] = params.reverbMix;
    d["reverb_freeze"] = params.reverbFreeze;
    // EQ
    d["eq_enabled"] = params.eqEnabled;
    d["eq_low_gain"] = params.eqLowGain;
    d["eq_mid_gain"] = params.eqMidGain;
    d["eq_high_gain"] = params.eqHighGain;
    d["eq_tilt"] = params.eqTilt;
    // Exciter
    d["exciter_enabled"] = params.exciterEnabled;
    d["exciter_warmth"] = params.exciterWarmth;
    d["exciter_presence"] = params.exciterPresence;
    d["exciter_air"] = params.exciterAir;
    // Tremolo
    d["trem_enabled"] = params.tremoloEnabled;
    d["trem_rate"] = params.tremoloRate;
    d["trem_depth"] = params.tremoloDepth;
    d["trem_waveform"] = params.tremoloWaveform;
    // Global
    d["mix"] = params.globalMix;
    d["output_level"] = params.outputLevel;
    d["preset"] = static_cast<int>(params.preset);
    d["preset_name"] = passionfxPresetToString(params.preset);
    d["bypass"] = params.bypass;
    return d;
}

PassionFXProcessor::Parameters dictToPassionfxParams(const py::dict& d) {
    PassionFXProcessor::Parameters params;
    // Gate
    if (d.contains("gate_enabled")) params.noiseGateEnabled = d["gate_enabled"].cast<bool>();
    if (d.contains("gate_threshold")) params.noiseGateThreshold = d["gate_threshold"].cast<float>();
    if (d.contains("gate_release")) params.noiseGateRelease = d["gate_release"].cast<float>();
    // Comp
    if (d.contains("comp_enabled")) params.compressorEnabled = d["comp_enabled"].cast<bool>();
    if (d.contains("comp_threshold")) params.compressorThreshold = d["comp_threshold"].cast<float>();
    if (d.contains("comp_ratio")) params.compressorRatio = d["comp_ratio"].cast<float>();
    if (d.contains("comp_attack")) params.compressorAttack = d["comp_attack"].cast<float>();
    if (d.contains("comp_release")) params.compressorRelease = d["comp_release"].cast<float>();
    if (d.contains("comp_glassy")) params.compressorGlassy = d["comp_glassy"].cast<bool>();
    // Wah
    if (d.contains("wah_enabled")) params.wahEnabled = d["wah_enabled"].cast<bool>();
    if (d.contains("wah_mode")) params.wahMode = d["wah_mode"].cast<int>();
    if (d.contains("wah_position")) params.wahPosition = d["wah_position"].cast<float>();
    if (d.contains("wah_q")) params.wahQ = d["wah_q"].cast<float>();
    // Phaser
    if (d.contains("phaser_enabled")) params.phaserEnabled = d["phaser_enabled"].cast<bool>();
    if (d.contains("phaser_rate")) params.phaserRate = d["phaser_rate"].cast<float>();
    if (d.contains("phaser_depth")) params.phaserDepth = d["phaser_depth"].cast<float>();
    if (d.contains("phaser_stages")) params.phaserStages = d["phaser_stages"].cast<int>();
    if (d.contains("phaser_feedback")) params.phaserFeedback = d["phaser_feedback"].cast<float>();
    // Chorus
    if (d.contains("chorus_enabled")) params.chorusEnabled = d["chorus_enabled"].cast<bool>();
    if (d.contains("chorus_rate")) params.chorusRate = d["chorus_rate"].cast<float>();
    if (d.contains("chorus_depth")) params.chorusDepth = d["chorus_depth"].cast<float>();
    if (d.contains("chorus_voices")) params.chorusVoices = d["chorus_voices"].cast<int>();
    if (d.contains("chorus_mix")) params.chorusMix = d["chorus_mix"].cast<float>();
    // PitchShifter
    if (d.contains("pitch_enabled")) params.pitchShifterEnabled = d["pitch_enabled"].cast<bool>();
    if (d.contains("pitch_semitones")) params.pitchShifterSemitones = d["pitch_semitones"].cast<float>();
    if (d.contains("pitch_mix")) params.pitchShifterMix = d["pitch_mix"].cast<float>();
    // Harmonizer
    if (d.contains("harm_enabled")) params.harmonizerEnabled = d["harm_enabled"].cast<bool>();
    if (d.contains("harm_voice1_interval")) params.harmonizerVoice1 = d["harm_voice1_interval"].cast<float>();
    if (d.contains("harm_voice2_interval")) params.harmonizerVoice2 = d["harm_voice2_interval"].cast<float>();
    if (d.contains("harm_detune_cents")) params.harmonizerDetune = d["harm_detune_cents"].cast<float>();
    if (d.contains("harm_mix")) params.harmonizerMix = d["harm_mix"].cast<float>();
    // Delay
    if (d.contains("delay_enabled")) params.delayEnabled = d["delay_enabled"].cast<bool>();
    if (d.contains("delay_time_l")) params.delayTimeL = d["delay_time_l"].cast<float>();
    if (d.contains("delay_time_r")) params.delayTimeR = d["delay_time_r"].cast<float>();
    if (d.contains("delay_feedback")) params.delayFeedback = d["delay_feedback"].cast<float>();
    if (d.contains("delay_mix")) params.delayMix = d["delay_mix"].cast<float>();
    if (d.contains("delay_freeze")) params.delayFreeze = d["delay_freeze"].cast<bool>();
    if (d.contains("delay_pitch_shift_l")) params.delayPitchShiftL = d["delay_pitch_shift_l"].cast<float>();
    if (d.contains("delay_pitch_shift_r")) params.delayPitchShiftR = d["delay_pitch_shift_r"].cast<float>();
    // Reverb
    if (d.contains("reverb_enabled")) params.reverbEnabled = d["reverb_enabled"].cast<bool>();
    if (d.contains("reverb_type")) params.reverbType = d["reverb_type"].cast<int>();
    if (d.contains("reverb_decay")) params.reverbDecay = d["reverb_decay"].cast<float>();
    if (d.contains("reverb_shimmer_amount")) params.reverbShimmerAmount = d["reverb_shimmer_amount"].cast<float>();
    if (d.contains("reverb_shimmer_interval")) params.reverbShimmerInterval = d["reverb_shimmer_interval"].cast<float>();
    if (d.contains("reverb_mix")) params.reverbMix = d["reverb_mix"].cast<float>();
    if (d.contains("reverb_freeze")) params.reverbFreeze = d["reverb_freeze"].cast<bool>();
    // EQ
    if (d.contains("eq_enabled")) params.eqEnabled = d["eq_enabled"].cast<bool>();
    if (d.contains("eq_low_gain")) params.eqLowGain = d["eq_low_gain"].cast<float>();
    if (d.contains("eq_mid_gain")) params.eqMidGain = d["eq_mid_gain"].cast<float>();
    if (d.contains("eq_high_gain")) params.eqHighGain = d["eq_high_gain"].cast<float>();
    if (d.contains("eq_tilt")) params.eqTilt = d["eq_tilt"].cast<float>();
    // Exciter
    if (d.contains("exciter_enabled")) params.exciterEnabled = d["exciter_enabled"].cast<bool>();
    if (d.contains("exciter_warmth")) params.exciterWarmth = d["exciter_warmth"].cast<float>();
    if (d.contains("exciter_presence")) params.exciterPresence = d["exciter_presence"].cast<float>();
    if (d.contains("exciter_air")) params.exciterAir = d["exciter_air"].cast<float>();
    // Tremolo
    if (d.contains("trem_enabled")) params.tremoloEnabled = d["trem_enabled"].cast<bool>();
    if (d.contains("trem_rate")) params.tremoloRate = d["trem_rate"].cast<float>();
    if (d.contains("trem_depth")) params.tremoloDepth = d["trem_depth"].cast<float>();
    if (d.contains("trem_waveform")) params.tremoloWaveform = d["trem_waveform"].cast<int>();
    // Global
    if (d.contains("mix")) params.globalMix = d["mix"].cast<float>();
    if (d.contains("output_level")) params.outputLevel = d["output_level"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

py::dict passionfxMeteringToDict(const PassionFXProcessor::Metering& m) {
    py::dict d;
    d["input_level_l"] = m.inputLevelL;
    d["input_level_r"] = m.inputLevelR;
    d["output_level_l"] = m.outputLevelL;
    d["output_level_r"] = m.outputLevelR;
    d["gate_gain"] = m.gateGain;
    d["comp_gain_reduction"] = m.compressorGainReduction;
    d["reverb_level_l"] = m.reverbLevelL;
    d["reverb_level_r"] = m.reverbLevelR;
    d["delay_level_l"] = m.delayLevelL;
    d["delay_level_r"] = m.delayLevelR;
    d["phaser_lfo_phase"] = m.phaserLfoPhase;
    d["tremolo_lfo_phase"] = m.tremoloLfoPhase;
    d["wah_position"] = m.wahPosition;
    return d;
}

// ========================================
// Filter/EQ Type Converters
// ========================================

// Convert FilterProcessor::BandParameters to Python dict
py::dict filterBandToDict(const FilterProcessor::BandParameters& band) {
    py::dict d;
    d["type"] = FilterProcessor::filterTypeToString(band.type);
    d["frequency"] = band.frequency;
    d["gain"] = band.gain;
    d["q"] = band.q;
    d["enabled"] = band.enabled;
    return d;
}

// Convert Python dict to FilterProcessor::BandParameters
FilterProcessor::BandParameters dictToFilterBand(const py::dict& d) {
    FilterProcessor::BandParameters band;
    if (d.contains("type")) band.type = FilterProcessor::stringToFilterType(d["type"].cast<std::string>());
    if (d.contains("frequency")) band.frequency = d["frequency"].cast<float>();
    if (d.contains("gain")) band.gain = d["gain"].cast<float>();
    if (d.contains("q")) band.q = d["q"].cast<float>();
    if (d.contains("enabled")) band.enabled = d["enabled"].cast<bool>();
    return band;
}

// Convert FilterProcessor::Parameters to Python dict
py::dict filterParamsToDict(const FilterProcessor::Parameters& params) {
    py::dict d;
    py::list bands;
    for (int i = 0; i < FilterProcessor::MAX_BANDS; ++i) {
        bands.append(filterBandToDict(params.bands[i]));
    }
    d["bands"] = bands;
    d["output_gain"] = params.outputGain;
    d["bypass"] = params.bypass;
    return d;
}

// Convert Python dict to FilterProcessor::Parameters
FilterProcessor::Parameters dictToFilterParams(const py::dict& d) {
    FilterProcessor::Parameters params;
    if (d.contains("bands")) {
        auto bands = d["bands"].cast<py::list>();
        for (size_t i = 0; i < std::min(static_cast<size_t>(FilterProcessor::MAX_BANDS), bands.size()); ++i) {
            params.bands[i] = dictToFilterBand(bands[i].cast<py::dict>());
        }
    }
    if (d.contains("output_gain")) params.outputGain = d["output_gain"].cast<float>();
    if (d.contains("bypass")) params.bypass = d["bypass"].cast<bool>();
    return params;
}

// ========================================
// MIDI Type Converters
// ========================================

// Convert CurveType to string
std::string curveTypeToString(CurveType curve) {
    switch (curve) {
        case CurveType::Logarithmic: return "logarithmic";
        case CurveType::Exponential: return "exponential";
        case CurveType::SCurve: return "s_curve";
        default: return "linear";
    }
}

// Convert string to CurveType
CurveType stringToCurveType(const std::string& str) {
    if (str == "logarithmic") return CurveType::Logarithmic;
    if (str == "exponential") return CurveType::Exponential;
    if (str == "s_curve") return CurveType::SCurve;
    return CurveType::Linear;
}

// Convert CommandActionType to string
std::string actionTypeToString(CommandActionType action) {
    switch (action) {
        case CommandActionType::ActivateChain: return "activate_chain";
        case CommandActionType::ToggleChain: return "toggle_chain";
        case CommandActionType::TogglePlugin: return "toggle_plugin";
        case CommandActionType::SetRouting: return "set_routing";
        case CommandActionType::NextPreset: return "next_preset";
        case CommandActionType::PreviousPreset: return "previous_preset";
        default: return "activate_chain";
    }
}

// Convert string to CommandActionType
CommandActionType stringToActionType(const std::string& str) {
    if (str == "activate_chain") return CommandActionType::ActivateChain;
    if (str == "toggle_chain") return CommandActionType::ToggleChain;
    if (str == "toggle_plugin") return CommandActionType::TogglePlugin;
    if (str == "set_routing") return CommandActionType::SetRouting;
    if (str == "next_preset") return CommandActionType::NextPreset;
    if (str == "previous_preset") return CommandActionType::PreviousPreset;
    return CommandActionType::ActivateChain;
}

// Convert MidiMessageType to string
std::string midiMessageTypeToString(MidiMessageType type) {
    switch (type) {
        case MidiMessageType::NoteOn: return "note_on";
        case MidiMessageType::NoteOff: return "note_off";
        case MidiMessageType::ControlChange: return "control_change";
        case MidiMessageType::ProgramChange: return "program_change";
        case MidiMessageType::PitchBend: return "pitch_bend";
        case MidiMessageType::ChannelPressure: return "channel_pressure";
        case MidiMessageType::Clock: return "clock";
        case MidiMessageType::Start: return "start";
        case MidiMessageType::Stop: return "stop";
        case MidiMessageType::Continue: return "continue";
        default: return "other";
    }
}

// Convert string to MidiMessageType
MidiMessageType stringToMidiMessageType(const std::string& str) {
    if (str == "note_on") return MidiMessageType::NoteOn;
    if (str == "note_off") return MidiMessageType::NoteOff;
    if (str == "control_change") return MidiMessageType::ControlChange;
    if (str == "program_change") return MidiMessageType::ProgramChange;
    if (str == "pitch_bend") return MidiMessageType::PitchBend;
    if (str == "channel_pressure") return MidiMessageType::ChannelPressure;
    if (str == "clock") return MidiMessageType::Clock;
    if (str == "start") return MidiMessageType::Start;
    if (str == "stop") return MidiMessageType::Stop;
    if (str == "continue") return MidiMessageType::Continue;
    return MidiMessageType::Other;
}

// Convert MidiCCMapping to Python dict
py::dict midiCCMappingToDict(const MidiCCMapping& mapping) {
    py::dict d;
    d["id"] = mapping.id;
    d["channel"] = mapping.channel;
    d["cc_number"] = mapping.ccNumber;
    d["target_plugin"] = mapping.targetPlugin;
    d["parameter_symbol"] = mapping.parameterSymbol;
    d["parameter_index"] = mapping.parameterIndex;
    d["min_value"] = mapping.minValue;
    d["max_value"] = mapping.maxValue;
    d["curve"] = curveTypeToString(mapping.curve);
    d["invert"] = mapping.invert;
    d["active"] = mapping.active;
    d["feedback_enabled"] = mapping.feedbackEnabled;
    d["feedback_cc"] = mapping.feedbackCC;
    return d;
}

// Create MidiCCMapping from Python dict
MidiCCMapping dictToMidiCCMapping(const py::dict& d) {
    MidiCCMapping mapping;
    if (d.contains("id")) mapping.id = d["id"].cast<int>();
    if (d.contains("channel")) mapping.channel = d["channel"].cast<int>();
    if (d.contains("cc_number")) mapping.ccNumber = d["cc_number"].cast<int>();
    if (d.contains("target_plugin")) mapping.targetPlugin = d["target_plugin"].cast<InstanceId>();
    if (d.contains("parameter_symbol")) mapping.parameterSymbol = d["parameter_symbol"].cast<std::string>();
    if (d.contains("parameter_index")) mapping.parameterIndex = d["parameter_index"].cast<int>();
    if (d.contains("min_value")) mapping.minValue = d["min_value"].cast<float>();
    if (d.contains("max_value")) mapping.maxValue = d["max_value"].cast<float>();
    if (d.contains("curve")) mapping.curve = stringToCurveType(d["curve"].cast<std::string>());
    if (d.contains("invert")) mapping.invert = d["invert"].cast<bool>();
    if (d.contains("active")) mapping.active = d["active"].cast<bool>();
    if (d.contains("feedback_enabled")) mapping.feedbackEnabled = d["feedback_enabled"].cast<bool>();
    if (d.contains("feedback_cc")) mapping.feedbackCC = d["feedback_cc"].cast<int>();
    return mapping;
}

// Convert MidiCommandTrigger to Python dict
py::dict midiCommandTriggerToDict(const MidiCommandTrigger& trigger) {
    py::dict d;
    d["id"] = trigger.id;
    d["trigger_type"] = midiMessageTypeToString(trigger.triggerType);
    d["channel"] = trigger.channel;
    d["data1"] = trigger.data1;
    d["data2_threshold"] = trigger.data2Threshold;
    d["action"] = actionTypeToString(trigger.action);
    d["target_chain_id"] = trigger.targetChainId;
    d["target_plugin_uri"] = trigger.targetPluginUri;
    d["active"] = trigger.active;
    return d;
}

// Create MidiCommandTrigger from Python dict
MidiCommandTrigger dictToMidiCommandTrigger(const py::dict& d) {
    MidiCommandTrigger trigger;
    if (d.contains("id")) trigger.id = d["id"].cast<int>();
    if (d.contains("trigger_type")) trigger.triggerType = stringToMidiMessageType(d["trigger_type"].cast<std::string>());
    if (d.contains("channel")) trigger.channel = d["channel"].cast<int>();
    if (d.contains("data1")) trigger.data1 = d["data1"].cast<int>();
    if (d.contains("data2_threshold")) trigger.data2Threshold = d["data2_threshold"].cast<int>();
    if (d.contains("action")) trigger.action = stringToActionType(d["action"].cast<std::string>());
    if (d.contains("target_chain_id")) trigger.targetChainId = d["target_chain_id"].cast<int>();
    if (d.contains("target_plugin_uri")) trigger.targetPluginUri = d["target_plugin_uri"].cast<std::string>();
    if (d.contains("active")) trigger.active = d["active"].cast<bool>();
    return trigger;
}

// Convert MidiLearnTarget to Python dict
py::dict midiLearnTargetToDict(const MidiLearnTarget& target) {
    py::dict d;
    d["chain_id"] = target.chainId;
    d["plugin_id"] = target.pluginId;
    d["parameter_symbol"] = target.parameterSymbol;
    d["parameter_index"] = target.parameterIndex;
    d["min_value"] = target.minValue;
    d["max_value"] = target.maxValue;
    d["curve"] = curveTypeToString(target.curve);
    d["is_active"] = target.isActive;
    return d;
}

// Convert MidiStatus to Python dict
py::dict midiStatusToDict(const MidiStatus& status) {
    py::dict d;
    d["enabled"] = status.enabled;
    d["input_open"] = status.inputOpen;
    d["output_open"] = status.outputOpen;
    d["input_device"] = status.inputDevice;
    d["output_device"] = status.outputDevice;
    d["mappings_count"] = status.mappingsCount;
    d["commands_count"] = status.commandsCount;
    d["learning"] = status.learning;
    d["last_channel"] = status.lastChannel;
    d["last_cc"] = status.lastCC;
    d["last_value"] = status.lastValue;
    return d;
}

// Convert MidiMessage to Python dict
py::dict midiMessageToDict(const MidiMessage& msg) {
    py::dict d;
    d["type"] = midiMessageTypeToString(msg.type);
    d["channel"] = msg.channel;
    d["data1"] = msg.data1;
    d["data2"] = msg.data2;
    d["timestamp"] = msg.timestamp;
    return d;
}

// ========================================
// Python Module Definition
// ========================================

PYBIND11_MODULE(map2_audio_engine, m) {
    m.doc() = "MAP2 Audio Engine - Professional Multi-Format Plugin Host with JUCE";

    // ========================================
    // Enums
    // ========================================

    py::enum_<PluginFormat>(m, "PluginFormat")
        .value("All", PluginFormat::All)
        .value("VST3", PluginFormat::VST3)
        .value("AudioUnit", PluginFormat::AudioUnit)
        .value("LV2", PluginFormat::LV2)
        .value("LADSPA", PluginFormat::LADSPA)
        .value("Unknown", PluginFormat::Unknown);

    // ========================================
    // Main Engine Class
    // ========================================

    py::class_<Map2AudioEngine, std::shared_ptr<Map2AudioEngine>>(m, "AudioEngine")
        .def(py::init<>())

        // ========================================
        // Lifecycle
        // ========================================

        .def("initialize", &Map2AudioEngine::initialize,
             py::arg("config_file") = "",
             "Initialize the audio engine")
        .def("shutdown", &Map2AudioEngine::shutdown,
             "Shutdown the audio engine")
        .def("is_running", &Map2AudioEngine::isRunning,
             "Check if engine is initialized")
        .def("get_version", &Map2AudioEngine::getVersion,
             "Get engine version string")

        // ========================================
        // System Info
        // ========================================

        .def("get_system_info", [](const Map2AudioEngine& self) {
            auto info = self.getSystemInfo();
            py::dict d;
            d["version"] = info.version;
            d["sample_rate"] = info.sampleRate;
            d["buffer_size"] = info.bufferSize;
            d["audio_device"] = info.audioDevice;
            d["lv2_path"] = info.lv2Path;
            d["running"] = info.running;
            d["audio_running"] = info.audioRunning;
            d["plugin_count"] = info.pluginCount;
            d["midi_enabled"] = info.midiEnabled;
            d["total_latency_samples"] = info.totalLatencySamples;
            d["total_latency_ms"] = info.totalLatencyMs;
            d["input_channels"] = self.getNumInputChannels();
            d["output_channels"] = self.getNumOutputChannels();
            d["available"] = true;
            d["initialized"] = info.running;
            return d;
        }, "Get comprehensive system information")

        // ========================================
        // Audio Control
        // ========================================

        .def("start_audio", &Map2AudioEngine::startAudio,
             "Start audio processing")
        .def("stop_audio", &Map2AudioEngine::stopAudio,
             "Stop audio processing")
        .def("is_audio_running", &Map2AudioEngine::isAudioRunning,
             "Check if audio is running")

        // ========================================
        // Configuration
        // ========================================

        .def("set_sample_rate", &Map2AudioEngine::setSampleRate,
             py::arg("rate"),
             "Set sample rate")
        .def("get_sample_rate", &Map2AudioEngine::getSampleRate,
             "Get sample rate")
        .def("set_buffer_size", &Map2AudioEngine::setBufferSize,
             py::arg("size"),
             "Set buffer size")
        .def("get_buffer_size", &Map2AudioEngine::getBufferSize,
             "Get buffer size")
        .def("set_audio_device", &Map2AudioEngine::setAudioDevice,
             py::arg("device"),
             "Set audio device")
        .def("get_audio_device", &Map2AudioEngine::getAudioDevice,
             "Get audio device name")
        .def("set_lv2_path", &Map2AudioEngine::setLv2Path,
             py::arg("path"),
             "Set LV2 plugin search path")
        .def("get_lv2_path", &Map2AudioEngine::getLv2Path,
             "Get LV2 plugin path")

        .def("set_num_input_channels", &Map2AudioEngine::setNumInputChannels,
             py::arg("channels"),
             "Set number of input channels (1-32)")
        .def("get_num_input_channels", &Map2AudioEngine::getNumInputChannels,
             "Get number of input channels")
        .def("set_num_output_channels", &Map2AudioEngine::setNumOutputChannels,
             py::arg("channels"),
             "Set number of output channels (1-32)")
        .def("get_num_output_channels", &Map2AudioEngine::getNumOutputChannels,
             "Get number of output channels")

        // ========================================
        // Plugin Management (Multi-Format)
        // ========================================

        .def("list_plugins", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& info : self.listPlugins()) {
                result.append(pluginInfoToDict(info));
            }
            return result;
        }, "List all available plugins (all formats)")

        .def("list_plugins_by_format", [](const Map2AudioEngine& self, PluginFormat format) {
            py::list result;
            for (const auto& info : self.listPlugins(format)) {
                result.append(pluginInfoToDict(info));
            }
            return result;
        }, py::arg("format"), "List plugins by format (VST3, AU, LV2, LADSPA)")

        .def("list_vst3_plugins", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& info : self.listPlugins(PluginFormat::VST3)) {
                result.append(pluginInfoToDict(info));
            }
            return result;
        }, "List all available VST3 plugins")

        .def("list_au_plugins", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& info : self.listPlugins(PluginFormat::AudioUnit)) {
                result.append(pluginInfoToDict(info));
            }
            return result;
        }, "List all available AudioUnit plugins")

        .def("list_lv2_plugins", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& info : self.listPlugins(PluginFormat::LV2)) {
                result.append(pluginInfoToDict(info));
            }
            return result;
        }, "List all available LV2 plugins")

        .def("get_plugin_info", [](const Map2AudioEngine& self, const std::string& uri) {
            auto info = self.getPluginInfo(uri);
            if (info) {
                return pluginInfoToDict(*info);
            }
            return py::dict();
        }, py::arg("uri"), "Get plugin info by URI/ID")

        .def("load_plugin", &Map2AudioEngine::loadPlugin,
             py::arg("uri"),
             "Load a plugin and return instance ID")
        .def("unload_plugin", &Map2AudioEngine::unloadPlugin,
             py::arg("instance_id"),
             "Unload a plugin by instance ID")
        .def("scan_for_plugins", &Map2AudioEngine::scanForPlugins,
             py::arg("rescan_all") = false,
             "Scan for available plugins")

        // ========================================
        // Chain Management
        // ========================================

        .def("get_chain_order", &Map2AudioEngine::getChainOrder,
             "Get current plugin chain order")
        .def("add_to_chain", &Map2AudioEngine::addToChain,
             py::arg("instance_id"), py::arg("position") = -1,
             "Add plugin to chain at position")
        .def("remove_from_chain", &Map2AudioEngine::removeFromChain,
             py::arg("instance_id"),
             "Remove plugin from chain")
        .def("reorder_chain", &Map2AudioEngine::reorderChain,
             py::arg("order"),
             "Reorder plugin chain")

        // ========================================
        // Sidechain Routing (NEW)
        // ========================================

        .def("connect_sidechain", &Map2AudioEngine::connectSidechain,
             py::arg("source"), py::arg("dest"), py::arg("dest_bus") = 1,
             "Connect sidechain from source to dest plugin")
        .def("disconnect_sidechain", &Map2AudioEngine::disconnectSidechain,
             py::arg("dest"), py::arg("dest_bus") = 1,
             "Disconnect sidechain from dest plugin")
        .def("get_sidechain_connections", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& conn : self.getSidechainConnections()) {
                result.append(sidechainConnectionToDict(conn));
            }
            return result;
        }, "Get all sidechain connections")

        // ========================================
        // Parameters
        // ========================================

        .def("set_parameter", &Map2AudioEngine::setParameter,
             py::arg("instance_id"), py::arg("param_index"), py::arg("value"),
             "Set plugin parameter by index")
        .def("set_parameter_by_name", &Map2AudioEngine::setParameterByName,
             py::arg("instance_id"), py::arg("name"), py::arg("value"),
             "Set plugin parameter by name")
        .def("get_parameter", &Map2AudioEngine::getParameter,
             py::arg("instance_id"), py::arg("param_index"),
             "Get plugin parameter by index")
        .def("get_parameter_by_name", &Map2AudioEngine::getParameterByName,
             py::arg("instance_id"), py::arg("name"),
             "Get plugin parameter by name")
        .def("set_bypass", &Map2AudioEngine::setBypass,
             py::arg("instance_id"), py::arg("bypass"),
             "Set plugin bypass state")

        // ========================================
        // Snapshots
        // ========================================

        .def("get_current_snapshot", &Map2AudioEngine::getCurrentSnapshot,
             "Get current snapshot ID (0-5)")
        .def("load_snapshot", &Map2AudioEngine::loadSnapshot,
             py::arg("snapshot_id"),
             "Load a snapshot")
        .def("save_snapshot", &Map2AudioEngine::saveSnapshot,
             py::arg("snapshot_id"), py::arg("name") = "",
             "Save current state to snapshot")
        .def("list_snapshots", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& snap : self.listSnapshots()) {
                result.append(snapshotToDict(snap));
            }
            return result;
        }, "List all snapshots")

        // ========================================
        // MIDI (Basic)
        // ========================================

        .def("enable_midi", &Map2AudioEngine::enableMidi,
             py::arg("enable"),
             "Enable or disable MIDI")
        .def("is_midi_enabled", &Map2AudioEngine::isMidiEnabled,
             "Check if MIDI is enabled")
        .def("get_midi_devices", &Map2AudioEngine::getMidiDevices,
             "List available MIDI devices")
        .def("set_midi_device", &Map2AudioEngine::setMidiDevice,
             py::arg("device"),
             "Set MIDI input device")

        // ========================================
        // MIDI CC Mappings (Enhanced)
        // ========================================

        .def("midi_add_cc_mapping", [](Map2AudioEngine& self, py::dict mapping) {
            return self.getMidiHandler().addCCMapping(dictToMidiCCMapping(mapping));
        }, py::arg("mapping"), "Add a CC mapping, returns mapping ID")

        .def("midi_update_cc_mapping", [](Map2AudioEngine& self, int id, py::dict mapping) {
            return self.getMidiHandler().updateCCMapping(id, dictToMidiCCMapping(mapping));
        }, py::arg("id"), py::arg("mapping"), "Update an existing CC mapping")

        .def("midi_remove_cc_mapping", [](Map2AudioEngine& self, int id) {
            return self.getMidiHandler().removeCCMapping(id);
        }, py::arg("id"), "Remove a CC mapping by ID")

        .def("midi_remove_cc_mapping_by_cc", [](Map2AudioEngine& self, int channel, int cc) {
            return self.getMidiHandler().removeCCMappingByCC(channel, cc);
        }, py::arg("channel"), py::arg("cc"), "Remove CC mapping by channel and CC number")

        .def("midi_get_all_cc_mappings", [](Map2AudioEngine& self) {
            py::list result;
            for (const auto& mapping : self.getMidiHandler().getAllCCMappings()) {
                result.append(midiCCMappingToDict(mapping));
            }
            return result;
        }, "Get all CC mappings")

        .def("midi_get_mappings_for_chain", [](Map2AudioEngine& self, int chainId) {
            py::list result;
            for (const auto& mapping : self.getMidiHandler().getMappingsForChain(chainId)) {
                result.append(midiCCMappingToDict(mapping));
            }
            return result;
        }, py::arg("chain_id"), "Get CC mappings for a specific chain")

        .def("midi_clear_cc_mappings", [](Map2AudioEngine& self) {
            self.getMidiHandler().clearCCMappings();
        }, "Clear all CC mappings")

        .def("midi_set_all_cc_mappings", [](Map2AudioEngine& self, py::list mappings) {
            std::vector<MidiCCMapping> midiMappings;
            for (auto item : mappings) {
                midiMappings.push_back(dictToMidiCCMapping(item.cast<py::dict>()));
            }
            self.getMidiHandler().setAllCCMappings(midiMappings);
        }, py::arg("mappings"), "Replace all CC mappings")

        .def("midi_set_active_chain", [](Map2AudioEngine& self, int chainId) {
            self.getMidiHandler().setActiveChain(chainId);
        }, py::arg("chain_id"), "Set the active chain for MIDI mappings")

        .def("midi_get_active_chain_id", [](const Map2AudioEngine& self) {
            return const_cast<Map2AudioEngine&>(self).getMidiHandler().getActiveChainId();
        }, "Get the active chain ID")

        // ========================================
        // MIDI Command Triggers
        // ========================================

        .def("midi_add_command_trigger", [](Map2AudioEngine& self, py::dict trigger) {
            return self.getMidiHandler().addCommandTrigger(dictToMidiCommandTrigger(trigger));
        }, py::arg("trigger"), "Add a command trigger, returns trigger ID")

        .def("midi_update_command_trigger", [](Map2AudioEngine& self, int id, py::dict trigger) {
            return self.getMidiHandler().updateCommandTrigger(id, dictToMidiCommandTrigger(trigger));
        }, py::arg("id"), py::arg("trigger"), "Update an existing command trigger")

        .def("midi_remove_command_trigger", [](Map2AudioEngine& self, int id) {
            return self.getMidiHandler().removeCommandTrigger(id);
        }, py::arg("id"), "Remove a command trigger by ID")

        .def("midi_get_all_command_triggers", [](Map2AudioEngine& self) {
            py::list result;
            for (const auto& trigger : self.getMidiHandler().getAllCommandTriggers()) {
                result.append(midiCommandTriggerToDict(trigger));
            }
            return result;
        }, "Get all command triggers")

        .def("midi_clear_command_triggers", [](Map2AudioEngine& self) {
            self.getMidiHandler().clearCommandTriggers();
        }, "Clear all command triggers")

        .def("midi_set_all_command_triggers", [](Map2AudioEngine& self, py::list triggers) {
            std::vector<MidiCommandTrigger> midiTriggers;
            for (auto item : triggers) {
                midiTriggers.push_back(dictToMidiCommandTrigger(item.cast<py::dict>()));
            }
            self.getMidiHandler().setAllCommandTriggers(midiTriggers);
        }, py::arg("triggers"), "Replace all command triggers")

        // ========================================
        // MIDI Learn
        // ========================================

        .def("midi_start_learn", [](Map2AudioEngine& self, int chainId, InstanceId pluginId,
                                     const std::string& paramSymbol, int paramIndex,
                                     float minVal, float maxVal, const std::string& curve) {
            self.getMidiHandler().startMidiLearn(chainId, pluginId, paramSymbol, paramIndex,
                                                  minVal, maxVal, stringToCurveType(curve));
        }, py::arg("chain_id"), py::arg("plugin_id"), py::arg("param_symbol"),
           py::arg("param_index"), py::arg("min_val") = 0.0f, py::arg("max_val") = 1.0f,
           py::arg("curve") = "linear", "Start MIDI learn mode for a parameter")

        .def("midi_stop_learn", [](Map2AudioEngine& self) {
            self.getMidiHandler().stopMidiLearn();
        }, "Stop MIDI learn mode")

        .def("midi_is_learning", [](const Map2AudioEngine& self) {
            return const_cast<Map2AudioEngine&>(self).getMidiHandler().isLearning();
        }, "Check if MIDI learn mode is active")

        .def("midi_get_learn_target", [](Map2AudioEngine& self) {
            return midiLearnTargetToDict(self.getMidiHandler().getLearnTarget());
        }, "Get the current learn target info")

        // ========================================
        // MIDI Output (Controller Feedback)
        // ========================================

        .def("midi_send_cc", [](Map2AudioEngine& self, int channel, int cc, int value) {
            return self.getMidiHandler().sendCC(channel, cc, value);
        }, py::arg("channel"), py::arg("cc"), py::arg("value"),
           "Send a CC message to MIDI output")

        .def("midi_send_program_change", [](Map2AudioEngine& self, int channel, int program) {
            return self.getMidiHandler().sendProgramChange(channel, program);
        }, py::arg("channel"), py::arg("program"),
           "Send a Program Change message")

        .def("midi_send_note_on", [](Map2AudioEngine& self, int channel, int note, int velocity) {
            return self.getMidiHandler().sendNoteOn(channel, note, velocity);
        }, py::arg("channel"), py::arg("note"), py::arg("velocity"),
           "Send a Note On message")

        .def("midi_send_note_off", [](Map2AudioEngine& self, int channel, int note, int velocity) {
            return self.getMidiHandler().sendNoteOff(channel, note, velocity);
        }, py::arg("channel"), py::arg("note"), py::arg("velocity") = 0,
           "Send a Note Off message")

        .def("midi_send_parameter_feedback", [](Map2AudioEngine& self, int channel, int cc, float value) {
            self.getMidiHandler().sendParameterFeedback(channel, cc, value);
        }, py::arg("channel"), py::arg("cc"), py::arg("value"),
           "Send parameter value feedback to controller (0.0-1.0)")

        .def("midi_sync_all_mappings_to_controller", [](Map2AudioEngine& self) {
            self.getMidiHandler().syncAllMappingsToController();
        }, "Sync all active mapping values to controller (for chain switch)")

        // ========================================
        // Chain-to-Program Mapping
        // ========================================

        .def("midi_set_chain_program_mapping", [](Map2AudioEngine& self, int chainId, int programNumber) {
            self.getMidiHandler().setChainProgramMapping(chainId, programNumber);
        }, py::arg("chain_id"), py::arg("program_number"),
           "Map a chain ID to a MIDI program number")

        .def("midi_get_chain_for_program", [](const Map2AudioEngine& self, int programNumber) {
            return const_cast<Map2AudioEngine&>(self).getMidiHandler().getChainForProgram(programNumber);
        }, py::arg("program_number"), "Get chain ID for a program number (-1 if not mapped)")

        .def("midi_get_program_for_chain", [](const Map2AudioEngine& self, int chainId) {
            return const_cast<Map2AudioEngine&>(self).getMidiHandler().getProgramForChain(chainId);
        }, py::arg("chain_id"), "Get program number for a chain ID (-1 if not mapped)")

        .def("midi_clear_chain_program_mappings", [](Map2AudioEngine& self) {
            self.getMidiHandler().clearChainProgramMappings();
        }, "Clear all chain-to-program mappings")

        // ========================================
        // MIDI Status
        // ========================================

        .def("midi_get_status", [](Map2AudioEngine& self) {
            return midiStatusToDict(self.getMidiHandler().getStatus());
        }, "Get comprehensive MIDI status")

        // ========================================
        // MIDI Device Management (Enhanced)
        // ========================================

        .def("midi_get_input_devices", [](Map2AudioEngine& self) {
            return self.getMidiHandler().getInputDevices();
        }, "Get list of available MIDI input devices")

        .def("midi_get_output_devices", [](Map2AudioEngine& self) {
            return self.getMidiHandler().getOutputDevices();
        }, "Get list of available MIDI output devices")

        .def("midi_open_input_device", [](Map2AudioEngine& self, const std::string& device) {
            return self.getMidiHandler().openInputDevice(device);
        }, py::arg("device"), "Open a MIDI input device by name")

        .def("midi_open_output_device", [](Map2AudioEngine& self, const std::string& device) {
            return self.getMidiHandler().openOutputDevice(device);
        }, py::arg("device"), "Open a MIDI output device by name")

        .def("midi_close_input_device", [](Map2AudioEngine& self) {
            self.getMidiHandler().closeInputDevice();
        }, "Close the current MIDI input device")

        .def("midi_close_output_device", [](Map2AudioEngine& self) {
            self.getMidiHandler().closeOutputDevice();
        }, "Close the current MIDI output device")

        .def("midi_close_all_devices", [](Map2AudioEngine& self) {
            self.getMidiHandler().closeAllDevices();
        }, "Close all MIDI devices")

        .def("midi_get_current_input_device", [](Map2AudioEngine& self) {
            return self.getMidiHandler().getCurrentInputDevice();
        }, "Get the current MIDI input device name")

        .def("midi_get_current_output_device", [](Map2AudioEngine& self) {
            return self.getMidiHandler().getCurrentOutputDevice();
        }, "Get the current MIDI output device name")

        // ========================================
        // MIDI Callbacks (for Python-side event handling)
        // ========================================

        .def("midi_set_parameter_callback", [](Map2AudioEngine& self, py::function callback) {
            self.getMidiHandler().setParameterCallback(
                [callback](InstanceId plugin, const std::string& param, int index, float value) {
                    py::gil_scoped_acquire acquire;
                    try {
                        callback(plugin, param, index, value);
                    } catch (const py::error_already_set& e) {
                        // Log error but don't crash
                    }
                });
        }, py::arg("callback"), "Set callback for parameter changes from MIDI (plugin_id, param_symbol, index, value)")

        .def("midi_set_command_callback", [](Map2AudioEngine& self, py::function callback) {
            self.getMidiHandler().setCommandCallback(
                [callback](const MidiCommandTrigger& trigger) {
                    py::gil_scoped_acquire acquire;
                    try {
                        callback(midiCommandTriggerToDict(trigger));
                    } catch (const py::error_already_set& e) {
                        // Log error but don't crash
                    }
                });
        }, py::arg("callback"), "Set callback for command triggers (trigger dict)")

        .def("midi_set_monitor_callback", [](Map2AudioEngine& self, py::function callback) {
            self.getMidiHandler().setMonitorCallback(
                [callback](const MidiMessage& msg) {
                    py::gil_scoped_acquire acquire;
                    try {
                        callback(midiMessageToDict(msg));
                    } catch (const py::error_already_set& e) {
                        // Log error but don't crash
                    }
                });
        }, py::arg("callback"), "Set callback for all MIDI messages (for monitoring)")

        .def("midi_set_learn_complete_callback", [](Map2AudioEngine& self, py::function callback) {
            self.getMidiHandler().setLearnCompleteCallback(
                [callback](int channel, int cc) {
                    py::gil_scoped_acquire acquire;
                    try {
                        callback(channel, cc);
                    } catch (const py::error_already_set& e) {
                        // Log error but don't crash
                    }
                });
        }, py::arg("callback"), "Set callback for when MIDI learn completes (channel, cc)")

        .def("midi_set_chain_switch_callback", [](Map2AudioEngine& self, py::function callback) {
            self.getMidiHandler().setChainSwitchCallback(
                [callback](int programNumber, int chainId) {
                    py::gil_scoped_acquire acquire;
                    try {
                        callback(programNumber, chainId);
                    } catch (const py::error_already_set& e) {
                        // Log error but don't crash
                    }
                });
        }, py::arg("callback"), "Set callback for chain switch via Program Change (program, chain_id)")

        // ========================================
        // VU Meters (Legacy)
        // ========================================

        .def("get_vu_levels", [](const Map2AudioEngine& self) {
            return vuLevelsToDict(self.getVuLevels());
        }, "Get master VU levels")

        .def("get_plugin_vu_levels", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& [id, vu] : self.getPluginVuLevels()) {
                py::dict d = vuLevelsToDict(vu);
                d["instance_id"] = id;
                result.append(d);
            }
            return result;
        }, "Get per-plugin VU levels")

        // ========================================
        // Spectrum Analysis (NEW)
        // ========================================

        .def("get_spectrum", [](const Map2AudioEngine& self) {
            return spectrumDataToDict(self.getSpectrum());
        }, "Get FFT spectrum data")

        .def("get_spectrum_magnitudes", &Map2AudioEngine::getSpectrumMagnitudes,
             "Get spectrum magnitude array")

        .def("get_spectrum_frequencies", &Map2AudioEngine::getSpectrumFrequencies,
             "Get spectrum frequency array")

        // ========================================
        // LUFS Loudness Metering (NEW)
        // ========================================

        .def("get_lufs_levels", [](const Map2AudioEngine& self) {
            return lufsLevelsToDict(self.getLufsLevels());
        }, "Get LUFS loudness levels (momentary, short-term, integrated)")

        .def("reset_integrated_loudness", &Map2AudioEngine::resetIntegratedLoudness,
             "Reset integrated loudness measurement")

        // ========================================
        // Phase Correlation (NEW)
        // ========================================

        .def("get_phase_correlation", [](const Map2AudioEngine& self) {
            return self.getPhaseCorrelation();
        }, "Get stereo phase correlation (-1 to +1)")

        .def("get_stereo_balance", &Map2AudioEngine::getStereoBalance,
             "Get stereo balance (-1=left, 0=center, +1=right)")

        .def("get_stereo_width", &Map2AudioEngine::getStereoWidth,
             "Get stereo width (0=mono, 1=full stereo)")

        // ========================================
        // CPU Monitoring (NEW)
        // ========================================

        .def("get_cpu_metrics", [](const Map2AudioEngine& self) {
            return cpuMetricsToDict(self.getCpuMetrics());
        }, "Get detailed CPU metrics")

        .def("get_total_cpu", &Map2AudioEngine::getTotalCpu,
             "Get total CPU usage percentage")

        .def("get_plugin_cpu", &Map2AudioEngine::getPluginCpu,
             py::arg("instance_id"),
             "Get CPU usage for specific plugin")

        .def("get_xrun_count", &Map2AudioEngine::getXRunCount,
             "Get number of audio dropouts (xruns)")

        // ========================================
        // Latency (NEW)
        // ========================================

        .def("get_total_latency_samples", &Map2AudioEngine::getTotalLatencySamples,
             "Get total chain latency in samples")

        .def("get_total_latency_ms", &Map2AudioEngine::getTotalLatencyMs,
             "Get total chain latency in milliseconds")

        .def("get_latency_breakdown", [](const Map2AudioEngine& self) {
            py::list result;
            for (const auto& [id, samples] : self.getPerPluginLatency()) {
                py::dict d;
                d["plugin_id"] = id;
                d["latency_samples"] = samples;
                d["latency_ms"] = samplesToMs(samples, self.getSampleRate());
                result.append(d);
            }
            return result;
        }, "Get per-plugin latency breakdown")

        // ========================================
        // Convolution / Cabinet IR (NEW)
        // ========================================

        .def("load_cabinet_ir", &Map2AudioEngine::loadCabinetIR,
             py::arg("path"),
             "Load cabinet impulse response file")

        .def("load_reverb_ir", &Map2AudioEngine::loadReverbIR,
             py::arg("path"),
             "Load reverb impulse response file")

        .def("unload_cabinet_ir", &Map2AudioEngine::unloadCabinetIR,
             "Unload cabinet IR")

        .def("unload_reverb_ir", &Map2AudioEngine::unloadReverbIR,
             "Unload reverb IR")

        .def("set_cabinet_mix", &Map2AudioEngine::setCabinetMix,
             py::arg("mix"),
             "Set cabinet dry/wet mix (0.0-1.0)")

        .def("set_reverb_mix", &Map2AudioEngine::setReverbMix,
             py::arg("mix"),
             "Set reverb dry/wet mix (0.0-1.0)")

        .def("set_cabinet_bypass", &Map2AudioEngine::setCabinetBypass,
             py::arg("bypass"),
             "Bypass cabinet IR")

        .def("set_reverb_bypass", &Map2AudioEngine::setReverbBypass,
             py::arg("bypass"),
             "Bypass reverb IR")

        .def("get_cabinet_ir_info", [](const Map2AudioEngine& self) {
            return irInfoToDict(self.getCabinetIRInfo());
        }, "Get cabinet IR info")

        .def("get_reverb_ir_info", [](const Map2AudioEngine& self) {
            return irInfoToDict(self.getReverbIRInfo());
        }, "Get reverb IR info")

        // ========================================
        // Dynamics - Compressor (NEW)
        // ========================================

        .def("set_compressor_threshold", &Map2AudioEngine::setCompressorThreshold,
             py::arg("db"),
             "Set compressor threshold in dB (-60 to 0)")

        .def("set_compressor_ratio", &Map2AudioEngine::setCompressorRatio,
             py::arg("ratio"),
             "Set compressor ratio (1 to 20)")

        .def("set_compressor_attack", &Map2AudioEngine::setCompressorAttack,
             py::arg("ms"),
             "Set compressor attack time in ms (0.1 to 500)")

        .def("set_compressor_release", &Map2AudioEngine::setCompressorRelease,
             py::arg("ms"),
             "Set compressor release time in ms (10 to 5000)")

        .def("set_compressor_knee", &Map2AudioEngine::setCompressorKnee,
             py::arg("db"),
             "Set compressor knee width in dB (0 to 24)")

        .def("set_compressor_makeup_gain", &Map2AudioEngine::setCompressorMakeupGain,
             py::arg("db"),
             "Set compressor makeup gain in dB (-12 to 24)")

        .def("set_compressor_auto_makeup", &Map2AudioEngine::setCompressorAutoMakeup,
             py::arg("enabled"),
             "Enable/disable auto makeup gain")

        .def("set_compressor_bypass", &Map2AudioEngine::setCompressorBypass,
             py::arg("bypass"),
             "Bypass compressor")

        .def("get_compressor_parameters", [](const Map2AudioEngine& self) {
            return dynamicsParamsToDict(self.getCompressorParameters());
        }, "Get all compressor parameters")

        .def("set_compressor_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setCompressorParameters(dictToDynamicsParams(params));
        }, py::arg("params"), "Set all compressor parameters at once")

        .def("get_compressor_metering", [](const Map2AudioEngine& self) {
            return dynamicsMeteringToDict(self.getCompressorMetering());
        }, "Get compressor metering (input, output, gain reduction)")

        // ========================================
        // Dynamics - Limiter (NEW)
        // ========================================

        .def("set_limiter_threshold", &Map2AudioEngine::setLimiterThreshold,
             py::arg("db"),
             "Set limiter ceiling/threshold in dB")

        .def("set_limiter_release", &Map2AudioEngine::setLimiterRelease,
             py::arg("ms"),
             "Set limiter release time in ms")

        .def("set_limiter_bypass", &Map2AudioEngine::setLimiterBypass,
             py::arg("bypass"),
             "Bypass limiter")

        .def("get_limiter_parameters", [](const Map2AudioEngine& self) {
            return dynamicsParamsToDict(self.getLimiterParameters());
        }, "Get all limiter parameters")

        .def("get_limiter_metering", [](const Map2AudioEngine& self) {
            return dynamicsMeteringToDict(self.getLimiterMetering());
        }, "Get limiter metering (input, output, gain reduction)")

        // ========================================
        // Dynamics - Noise Gate (NEW)
        // ========================================

        .def("set_gate_threshold", &Map2AudioEngine::setGateThreshold,
             py::arg("db"),
             "Set noise gate threshold in dB")

        .def("set_gate_ratio", &Map2AudioEngine::setGateRatio,
             py::arg("ratio"),
             "Set noise gate ratio (attenuation below threshold)")

        .def("set_gate_attack", &Map2AudioEngine::setGateAttack,
             py::arg("ms"),
             "Set noise gate attack time in ms")

        .def("set_gate_release", &Map2AudioEngine::setGateRelease,
             py::arg("ms"),
             "Set noise gate release time in ms")

        .def("set_gate_bypass", &Map2AudioEngine::setGateBypass,
             py::arg("bypass"),
             "Bypass noise gate")

        .def("get_gate_parameters", [](const Map2AudioEngine& self) {
            return dynamicsParamsToDict(self.getGateParameters());
        }, "Get all noise gate parameters")

        .def("get_gate_metering", [](const Map2AudioEngine& self) {
            return dynamicsMeteringToDict(self.getGateMetering());
        }, "Get noise gate metering (input, output, gain reduction)")

        // ========================================
        // Dynamics - Combined Access (NEW)
        // ========================================

        .def("get_dynamics_metering", [](const Map2AudioEngine& self) {
            py::dict d;
            d["compressor"] = dynamicsMeteringToDict(self.getCompressorMetering());
            d["limiter"] = dynamicsMeteringToDict(self.getLimiterMetering());
            d["gate"] = dynamicsMeteringToDict(self.getGateMetering());
            return d;
        }, "Get all dynamics processor metering")

        // ========================================
        // EQ / Filter Processing (NEW)
        // ========================================

        .def("set_eq_band", [](Map2AudioEngine& self, int index, py::dict params) {
            self.setEQBand(index, dictToFilterBand(params));
        }, py::arg("index"), py::arg("params"), "Set EQ band parameters")

        .def("set_eq_band_frequency", &Map2AudioEngine::setEQBandFrequency,
             py::arg("index"), py::arg("hz"),
             "Set EQ band frequency in Hz")

        .def("set_eq_band_gain", &Map2AudioEngine::setEQBandGain,
             py::arg("index"), py::arg("db"),
             "Set EQ band gain in dB")

        .def("set_eq_band_q", &Map2AudioEngine::setEQBandQ,
             py::arg("index"), py::arg("q"),
             "Set EQ band Q factor")

        .def("set_eq_band_type", [](Map2AudioEngine& self, int index, const std::string& type) {
            self.setEQBandType(index, FilterProcessor::stringToFilterType(type));
        }, py::arg("index"), py::arg("type"), "Set EQ band filter type")

        .def("set_eq_band_enabled", &Map2AudioEngine::setEQBandEnabled,
             py::arg("index"), py::arg("enabled"),
             "Enable/disable EQ band")

        .def("get_eq_band", [](const Map2AudioEngine& self, int index) {
            return filterBandToDict(self.getEQBand(index));
        }, py::arg("index"), "Get EQ band parameters")

        .def("set_eq_output_gain", &Map2AudioEngine::setEQOutputGain,
             py::arg("db"),
             "Set EQ output gain in dB")

        .def("get_eq_output_gain", &Map2AudioEngine::getEQOutputGain,
             "Get EQ output gain in dB")

        .def("set_eq_bypass", &Map2AudioEngine::setEQBypass,
             py::arg("bypass"),
             "Bypass EQ")

        .def("is_eq_bypassed", &Map2AudioEngine::isEQBypassed,
             "Check if EQ is bypassed")

        .def("get_eq_parameters", [](const Map2AudioEngine& self) {
            return filterParamsToDict(self.getEQParameters());
        }, "Get all EQ parameters")

        .def("set_eq_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setEQParameters(dictToFilterParams(params));
        }, py::arg("params"), "Set all EQ parameters")

        .def("get_eq_frequency_response", [](const Map2AudioEngine& self, py::list frequencies) {
            std::vector<float> freqs;
            for (auto f : frequencies) {
                freqs.push_back(f.cast<float>());
            }
            auto response = self.getEQFrequencyResponse(freqs);
            py::list result;
            for (float r : response) {
                result.append(r);
            }
            return result;
        }, py::arg("frequencies"), "Get EQ frequency response at given frequencies")

        // ========================================
        // Parallel Chains (NEW)
        // ========================================

        .def("create_parallel_group", [](Map2AudioEngine& self, int position, int numBranches) {
            return self.getAudioGraph().createParallelGroup(position, numBranches);
        }, py::arg("position") = -1, py::arg("num_branches") = 2,
           "Create a parallel processing group, returns group ID")

        .def("remove_parallel_group", [](Map2AudioEngine& self, int groupId) {
            return self.getAudioGraph().removeParallelGroup(groupId);
        }, py::arg("group_id"), "Remove a parallel group")

        .def("add_to_parallel_branch", [](Map2AudioEngine& self, int groupId, int branchIndex,
                                           InstanceId pluginId, int position) {
            return self.getAudioGraph().addToParallelBranch(groupId, branchIndex, pluginId, position);
        }, py::arg("group_id"), py::arg("branch_index"), py::arg("plugin_id"), py::arg("position") = -1,
           "Add a plugin to a parallel branch")

        .def("remove_from_parallel_branch", [](Map2AudioEngine& self, int groupId, int branchIndex,
                                                InstanceId pluginId) {
            return self.getAudioGraph().removeFromParallelBranch(groupId, branchIndex, pluginId);
        }, py::arg("group_id"), py::arg("branch_index"), py::arg("plugin_id"),
           "Remove a plugin from a parallel branch")

        .def("set_parallel_ab_blend", [](Map2AudioEngine& self, int groupId, float blend) {
            self.getAudioGraph().setParallelABBlend(groupId, blend);
        }, py::arg("group_id"), py::arg("blend"),
           "Set A/B blend for parallel group (0.0 = all A, 1.0 = all B)")

        .def("get_parallel_ab_blend", [](const Map2AudioEngine& self, int groupId) {
            return const_cast<Map2AudioEngine&>(self).getAudioGraph().getParallelABBlend(groupId);
        }, py::arg("group_id"), "Get A/B blend for parallel group")

        .def("set_parallel_branch_level", [](Map2AudioEngine& self, int groupId, int branchIndex, float level) {
            self.getAudioGraph().setParallelBranchLevel(groupId, branchIndex, level);
        }, py::arg("group_id"), py::arg("branch_index"), py::arg("level"),
           "Set individual branch level (0.0 - 2.0)")

        .def("set_parallel_bypass", [](Map2AudioEngine& self, int groupId, bool bypass) {
            self.getAudioGraph().setParallelBypass(groupId, bypass);
        }, py::arg("group_id"), py::arg("bypass"),
           "Bypass a parallel group")

        .def("get_parallel_groups", [](const Map2AudioEngine& self) {
            py::list result;
            auto groups = const_cast<Map2AudioEngine&>(self).getAudioGraph().getParallelGroups();
            for (const auto& group : groups) {
                py::dict d;
                d["id"] = group.id;
                d["ab_blend"] = group.abBlend;
                d["master_level"] = group.masterLevel;
                d["bypass"] = group.bypass;

                py::list branches;
                for (const auto& branch : group.branches) {
                    py::list branchPlugins;
                    for (auto pluginId : branch) {
                        branchPlugins.append(pluginId);
                    }
                    branches.append(branchPlugins);
                }
                d["branches"] = branches;

                py::list levels;
                for (float level : group.branchLevels) {
                    levels.append(level);
                }
                d["branch_levels"] = levels;

                result.append(d);
            }
            return result;
        }, "Get all parallel groups")

        // ========================================
        // Neural Amp Modeler (NEW - RT-safe)
        // ========================================

        .def("is_nam_available", &Map2AudioEngine::isNAMAvailable,
             "Check if NAM support is compiled in")

        .def("load_nam_model", &Map2AudioEngine::loadNAMModel,
             py::arg("path"),
             "Load a NAM model (.nam file)")

        .def("unload_nam_model", &Map2AudioEngine::unloadNAMModel,
             "Unload current NAM model")

        .def("is_nam_model_loaded", &Map2AudioEngine::isNAMModelLoaded,
             "Check if NAM model is loaded")

        .def("is_nam_loading", &Map2AudioEngine::isNAMLoading,
             "Check if NAM model is currently loading")

        .def("get_nam_model_info", [](const Map2AudioEngine& self) {
            auto info = self.getNAMModelInfo();
            py::dict d;
            d["path"] = info.path;
            d["name"] = info.name;
            d["expected_sample_rate"] = info.expectedSampleRate;
            d["input_channels"] = info.inputChannels;
            d["output_channels"] = info.outputChannels;
            d["has_input_level"] = info.hasInputLevel;
            d["has_output_level"] = info.hasOutputLevel;
            d["input_level"] = info.inputLevel;
            d["output_level"] = info.outputLevel;
            d["loaded"] = info.loaded;
            return d;
        }, "Get NAM model information")

        .def("set_nam_input_gain", &Map2AudioEngine::setNAMInputGain,
             py::arg("db"),
             "Set NAM input gain in dB")

        .def("get_nam_input_gain", &Map2AudioEngine::getNAMInputGain,
             "Get NAM input gain in dB")

        .def("set_nam_output_gain", &Map2AudioEngine::setNAMOutputGain,
             py::arg("db"),
             "Set NAM output gain in dB")

        .def("get_nam_output_gain", &Map2AudioEngine::getNAMOutputGain,
             "Get NAM output gain in dB")

        .def("set_nam_bypass", &Map2AudioEngine::setNAMBypass,
             py::arg("bypass"),
             "Bypass NAM processor")

        .def("is_nam_bypassed", &Map2AudioEngine::isNAMBypassed,
             "Check if NAM is bypassed")

        .def("set_nam_normalize", &Map2AudioEngine::setNAMNormalize,
             py::arg("normalize"),
             "Enable/disable NAM output normalization")

        .def("is_nam_normalized", &Map2AudioEngine::isNAMNormalized,
             "Check if NAM normalization is enabled")

        .def("get_nam_input_level", &Map2AudioEngine::getNAMInputLevel,
             "Get NAM input metering level in dB")

        .def("get_nam_output_level", &Map2AudioEngine::getNAMOutputLevel,
             "Get NAM output metering level in dB")

        // ========================================
        // Chorus Processor (NEW)
        // ========================================

        .def("set_chorus_rate", &Map2AudioEngine::setChorusRate,
             py::arg("hz"),
             "Set chorus LFO rate in Hz (0.1 to 10)")

        .def("get_chorus_rate", &Map2AudioEngine::getChorusRate,
             "Get chorus LFO rate in Hz")

        .def("set_chorus_depth", &Map2AudioEngine::setChorusDepth,
             py::arg("depth"),
             "Set chorus depth (0 to 1)")

        .def("get_chorus_depth", &Map2AudioEngine::getChorusDepth,
             "Get chorus depth")

        .def("set_chorus_centre_delay", &Map2AudioEngine::setChorusCentreDelay,
             py::arg("ms"),
             "Set chorus centre delay in ms (1 to 30)")

        .def("get_chorus_centre_delay", &Map2AudioEngine::getChorusCentreDelay,
             "Get chorus centre delay in ms")

        .def("set_chorus_feedback", &Map2AudioEngine::setChorusFeedback,
             py::arg("feedback"),
             "Set chorus feedback (-1 to 1)")

        .def("get_chorus_feedback", &Map2AudioEngine::getChorusFeedback,
             "Get chorus feedback")

        .def("set_chorus_mix", &Map2AudioEngine::setChorusMix,
             py::arg("mix"),
             "Set chorus wet/dry mix (0 to 1)")

        .def("get_chorus_mix", &Map2AudioEngine::getChorusMix,
             "Get chorus mix")

        .def("set_chorus_spread", &Map2AudioEngine::setChorusSpread,
             py::arg("spread"),
             "Set chorus stereo spread (0 to 1)")

        .def("get_chorus_spread", &Map2AudioEngine::getChorusSpread,
             "Get chorus stereo spread")

        .def("set_chorus_bypass", &Map2AudioEngine::setChorusBypass,
             py::arg("bypass"),
             "Bypass chorus processor")

        .def("is_chorus_bypassed", &Map2AudioEngine::isChorusBypassed,
             "Check if chorus is bypassed")

        .def("get_chorus_parameters", [](const Map2AudioEngine& self) {
            return chorusParamsToDict(self.getChorusParameters());
        }, "Get all chorus parameters")

        .def("set_chorus_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setChorusParameters(dictToChorusParams(params));
        }, py::arg("params"), "Set all chorus parameters at once")

        .def("get_chorus_metering", [](const Map2AudioEngine& self) {
            return chorusMeteringToDict(self.getChorusMetering());
        }, "Get chorus metering (input, output, LFO phase)")

        // ========================================
        // Phaser Processor (NEW)
        // ========================================

        .def("set_phaser_rate", &Map2AudioEngine::setPhaserRate,
             py::arg("hz"),
             "Set phaser LFO rate in Hz (0.05 to 5)")

        .def("get_phaser_rate", &Map2AudioEngine::getPhaserRate,
             "Get phaser LFO rate in Hz")

        .def("set_phaser_depth", &Map2AudioEngine::setPhaserDepth,
             py::arg("depth"),
             "Set phaser depth (0 to 1)")

        .def("get_phaser_depth", &Map2AudioEngine::getPhaserDepth,
             "Get phaser depth")

        .def("set_phaser_centre_frequency", &Map2AudioEngine::setPhaserCentreFrequency,
             py::arg("hz"),
             "Set phaser centre frequency in Hz (100 to 10000)")

        .def("get_phaser_centre_frequency", &Map2AudioEngine::getPhaserCentreFrequency,
             "Get phaser centre frequency in Hz")

        .def("set_phaser_feedback", &Map2AudioEngine::setPhaserFeedback,
             py::arg("feedback"),
             "Set phaser feedback (-1 to 1)")

        .def("get_phaser_feedback", &Map2AudioEngine::getPhaserFeedback,
             "Get phaser feedback")

        .def("set_phaser_mix", &Map2AudioEngine::setPhaserMix,
             py::arg("mix"),
             "Set phaser wet/dry mix (0 to 1)")

        .def("get_phaser_mix", &Map2AudioEngine::getPhaserMix,
             "Get phaser mix")

        .def("set_phaser_bypass", &Map2AudioEngine::setPhaserBypass,
             py::arg("bypass"),
             "Bypass phaser processor")

        .def("is_phaser_bypassed", &Map2AudioEngine::isPhaserBypassed,
             "Check if phaser is bypassed")

        .def("get_phaser_parameters", [](const Map2AudioEngine& self) {
            return phaserParamsToDict(self.getPhaserParameters());
        }, "Get all phaser parameters")

        .def("set_phaser_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setPhaserParameters(dictToPhaserParams(params));
        }, py::arg("params"), "Set all phaser parameters at once")

        .def("get_phaser_metering", [](const Map2AudioEngine& self) {
            return phaserMeteringToDict(self.getPhaserMetering());
        }, "Get phaser metering (input, output, LFO phase)")

        // ========================================
        // Pitch Shifter / EVH Harmonizer (NEW)
        // ========================================

        .def("set_pitch_shifter_pitch_l", &Map2AudioEngine::setPitchShifterPitchL,
             py::arg("cents"),
             "Set left channel pitch shift in cents (-100 to +100)")

        .def("get_pitch_shifter_pitch_l", &Map2AudioEngine::getPitchShifterPitchL,
             "Get left channel pitch shift in cents")

        .def("set_pitch_shifter_pitch_r", &Map2AudioEngine::setPitchShifterPitchR,
             py::arg("cents"),
             "Set right channel pitch shift in cents (-100 to +100)")

        .def("get_pitch_shifter_pitch_r", &Map2AudioEngine::getPitchShifterPitchR,
             "Get right channel pitch shift in cents")

        .def("set_pitch_shifter_delay_l", &Map2AudioEngine::setPitchShifterDelayL,
             py::arg("ms"),
             "Set left channel delay in ms (0 to 100)")

        .def("get_pitch_shifter_delay_l", &Map2AudioEngine::getPitchShifterDelayL,
             "Get left channel delay in ms")

        .def("set_pitch_shifter_delay_r", &Map2AudioEngine::setPitchShifterDelayR,
             py::arg("ms"),
             "Set right channel delay in ms (0 to 100)")

        .def("get_pitch_shifter_delay_r", &Map2AudioEngine::getPitchShifterDelayR,
             "Get right channel delay in ms")

        .def("set_pitch_shifter_feedback", &Map2AudioEngine::setPitchShifterFeedback,
             py::arg("feedback"),
             "Set pitch shifter feedback (0 to 0.9)")

        .def("get_pitch_shifter_feedback", &Map2AudioEngine::getPitchShifterFeedback,
             "Get pitch shifter feedback")

        .def("set_pitch_shifter_mix", &Map2AudioEngine::setPitchShifterMix,
             py::arg("percent"),
             "Set pitch shifter wet mix (0 to 100%)")

        .def("get_pitch_shifter_mix", &Map2AudioEngine::getPitchShifterMix,
             "Get pitch shifter mix")

        .def("set_pitch_shifter_spread", &Map2AudioEngine::setPitchShifterSpread,
             py::arg("percent"),
             "Set pitch shifter stereo spread (0 to 200%)")

        .def("get_pitch_shifter_spread", &Map2AudioEngine::getPitchShifterSpread,
             "Get pitch shifter stereo spread")

        .def("set_pitch_shifter_preset", [](Map2AudioEngine& self, const std::string& preset) {
            self.setPitchShifterPreset(stringToPitchPreset(preset));
        }, py::arg("preset"), "Set pitch shifter preset by name")

        .def("get_pitch_shifter_preset", [](const Map2AudioEngine& self) {
            return pitchPresetToString(self.getPitchShifterPreset());
        }, "Get current pitch shifter preset name")

        .def("set_pitch_shifter_bypass", &Map2AudioEngine::setPitchShifterBypass,
             py::arg("bypass"),
             "Bypass pitch shifter processor")

        .def("is_pitch_shifter_bypassed", &Map2AudioEngine::isPitchShifterBypassed,
             "Check if pitch shifter is bypassed")

        .def("get_pitch_shifter_parameters", [](const Map2AudioEngine& self) {
            return pitchShifterParamsToDict(self.getPitchShifterParameters());
        }, "Get all pitch shifter parameters")

        .def("set_pitch_shifter_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setPitchShifterParameters(dictToPitchShifterParams(params));
        }, py::arg("params"), "Set all pitch shifter parameters at once")

        .def("get_pitch_shifter_metering", [](const Map2AudioEngine& self) {
            return pitchShifterMeteringToDict(self.getPitchShifterMetering());
        }, "Get pitch shifter metering (input, output, grain phase)")

        .def("get_pitch_shifter_preset_info", [](const Map2AudioEngine& /*self*/, const std::string& preset) {
            return pitchPresetInfoToDict(
                PitchShifterProcessor::getPresetInfo(stringToPitchPreset(preset))
            );
        }, py::arg("preset"), "Get preset info (song, album, year, description)")

        .def("get_pitch_shifter_presets", [](const Map2AudioEngine& /*self*/) {
            py::list result;
            int numPresets = PitchShifterProcessor::getNumPresets();
            for (int i = 0; i < numPresets; ++i) {
                auto preset = static_cast<PitchShifterProcessor::Preset>(i);
                py::dict d;
                d["id"] = pitchPresetToString(preset);
                auto info = PitchShifterProcessor::getPresetInfo(preset);
                d["name"] = info.name ? std::string(info.name) : "";
                d["song"] = info.song ? std::string(info.song) : "";
                d["album"] = info.album ? std::string(info.album) : "";
                d["year"] = info.year ? std::string(info.year) : "";
                d["description"] = info.description ? std::string(info.description) : "";
                result.append(d);
            }
            return result;
        }, "Get all available pitch shifter presets (Van Halen songs)")

        // ========================================
        // Boss XS-1 Polyphonic Pitch Shifter
        // ========================================

        .def("set_boss_xs1_shift_amount", &Map2AudioEngine::setBossXS1ShiftAmount,
             py::arg("semitones"),
             "Set Boss XS-1 pitch shift amount (-7 to +7 semitones)")

        .def("get_boss_xs1_shift_amount", &Map2AudioEngine::getBossXS1ShiftAmount,
             "Get Boss XS-1 pitch shift amount")

        .def("set_boss_xs1_balance", &Map2AudioEngine::setBossXS1Balance,
             py::arg("percent"),
             "Set Boss XS-1 wet/dry balance (0-100%)")

        .def("get_boss_xs1_balance", &Map2AudioEngine::getBossXS1Balance,
             "Get Boss XS-1 balance")

        .def("set_boss_xs1_detune_mode", &Map2AudioEngine::setBossXS1DetuneMode,
             py::arg("enabled"),
             "Enable Boss XS-1 detune mode (±20 cents instead of semitones)")

        .def("is_boss_xs1_detune_mode", &Map2AudioEngine::isBossXS1DetuneMode,
             "Check if Boss XS-1 is in detune mode")

        .def("set_boss_xs1_detune_amount", &Map2AudioEngine::setBossXS1DetuneAmount,
             py::arg("cents"),
             "Set Boss XS-1 detune amount (±20 cents)")

        .def("get_boss_xs1_detune_amount", &Map2AudioEngine::getBossXS1DetuneAmount,
             "Get Boss XS-1 detune amount")

        .def("set_boss_xs1_glide", &Map2AudioEngine::setBossXS1Glide,
             py::arg("ms"),
             "Set Boss XS-1 glide time (0-100 ms)")

        .def("get_boss_xs1_glide", &Map2AudioEngine::getBossXS1Glide,
             "Get Boss XS-1 glide time")

        .def("set_boss_xs1_feedback", &Map2AudioEngine::setBossXS1Feedback,
             py::arg("feedback"),
             "Set Boss XS-1 feedback (0 to 0.7)")

        .def("get_boss_xs1_feedback", &Map2AudioEngine::getBossXS1Feedback,
             "Get Boss XS-1 feedback")

        .def("set_boss_xs1_pedal_enabled", &Map2AudioEngine::setBossXS1PedalEnabled,
             py::arg("enabled"),
             "Enable Boss XS-1 expression pedal control")

        .def("is_boss_xs1_pedal_enabled", &Map2AudioEngine::isBossXS1PedalEnabled,
             "Check if Boss XS-1 expression pedal is enabled")

        .def("set_boss_xs1_pedal_position", &Map2AudioEngine::setBossXS1PedalPosition,
             py::arg("position"),
             "Set Boss XS-1 expression pedal position (0-100%)")

        .def("get_boss_xs1_pedal_position", &Map2AudioEngine::getBossXS1PedalPosition,
             "Get Boss XS-1 expression pedal position")

        .def("set_boss_xs1_pedal_range", &Map2AudioEngine::setBossXS1PedalRange,
             py::arg("min_semitones"), py::arg("max_semitones"),
             "Set Boss XS-1 expression pedal range")

        .def("get_boss_xs1_pedal_min", &Map2AudioEngine::getBossXS1PedalMin,
             "Get Boss XS-1 expression pedal min")

        .def("get_boss_xs1_pedal_max", &Map2AudioEngine::getBossXS1PedalMax,
             "Get Boss XS-1 expression pedal max")

        .def("set_boss_xs1_preset", [](Map2AudioEngine& self, const std::string& preset) {
            self.setBossXS1Preset(stringToBossXS1Preset(preset));
        }, py::arg("preset"), "Set Boss XS-1 preset by name")

        .def("get_boss_xs1_preset", [](const Map2AudioEngine& self) {
            return bossXS1PresetToString(self.getBossXS1Preset());
        }, "Get current Boss XS-1 preset name")

        .def("set_boss_xs1_bypass", &Map2AudioEngine::setBossXS1Bypass,
             py::arg("bypass"),
             "Bypass Boss XS-1 processor")

        .def("is_boss_xs1_bypassed", &Map2AudioEngine::isBossXS1Bypassed,
             "Check if Boss XS-1 is bypassed")

        .def("get_boss_xs1_parameters", [](const Map2AudioEngine& self) {
            return bossXS1ParamsToDict(self.getBossXS1Parameters());
        }, "Get all Boss XS-1 parameters")

        .def("set_boss_xs1_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setBossXS1Parameters(dictToBossXS1Params(params));
        }, py::arg("params"), "Set all Boss XS-1 parameters at once")

        .def("get_boss_xs1_input_level", &Map2AudioEngine::getBossXS1InputLevel,
             "Get Boss XS-1 input level (dB)")

        .def("get_boss_xs1_output_level", &Map2AudioEngine::getBossXS1OutputLevel,
             "Get Boss XS-1 output level (dB)")

        .def("get_boss_xs1_presets", [](const Map2AudioEngine& /*self*/) {
            py::list result;
            int numPresets = Map2AudioEngine::getBossXS1NumPresets();
            for (int i = 0; i < numPresets; ++i) {
                auto preset = static_cast<BossXS1PolyShifterProcessor::Preset>(i);
                py::dict d;
                d["id"] = bossXS1PresetToString(preset);
                d["name"] = Map2AudioEngine::getBossXS1PresetName(preset);
                result.append(d);
            }
            return result;
        }, "Get all available Boss XS-1 presets")

        // ========================================
        // ShoeGaze Multi-Effect Processor
        // ========================================

        // Primary controls
        .def("set_shoegaze_atmosphere", &Map2AudioEngine::setShoeGazeAtmosphere,
             py::arg("percent"),
             "Set ShoeGaze atmosphere amount (0-100%)")
        .def("get_shoegaze_atmosphere", &Map2AudioEngine::getShoeGazeAtmosphere,
             "Get ShoeGaze atmosphere amount")

        .def("set_shoegaze_decay", &Map2AudioEngine::setShoeGazeDecay,
             py::arg("seconds"),
             "Set ShoeGaze reverb decay time (0.5-30s)")
        .def("get_shoegaze_decay", &Map2AudioEngine::getShoeGazeDecay,
             "Get ShoeGaze reverb decay time")

        .def("set_shoegaze_shimmer", &Map2AudioEngine::setShoeGazeShimmer,
             py::arg("percent"),
             "Set ShoeGaze shimmer amount (0-100%)")
        .def("get_shoegaze_shimmer", &Map2AudioEngine::getShoeGazeShimmer,
             "Get ShoeGaze shimmer amount")

        .def("set_shoegaze_shimmer_pitch", &Map2AudioEngine::setShoeGazeShimmerPitch,
             py::arg("semitones"),
             "Set ShoeGaze shimmer pitch shift (-12 to +24 semitones)")
        .def("get_shoegaze_shimmer_pitch", &Map2AudioEngine::getShoeGazeShimmerPitch,
             "Get ShoeGaze shimmer pitch shift")

        .def("set_shoegaze_modulation", &Map2AudioEngine::setShoeGazeModulation,
             py::arg("percent"),
             "Set ShoeGaze modulation depth (0-100%)")
        .def("get_shoegaze_modulation", &Map2AudioEngine::getShoeGazeModulation,
             "Get ShoeGaze modulation depth")

        .def("set_shoegaze_mod_rate", &Map2AudioEngine::setShoeGazeModRate,
             py::arg("hz"),
             "Set ShoeGaze modulation rate (0.1-5 Hz)")
        .def("get_shoegaze_mod_rate", &Map2AudioEngine::getShoeGazeModRate,
             "Get ShoeGaze modulation rate")

        .def("set_shoegaze_drive", &Map2AudioEngine::setShoeGazeDrive,
             py::arg("percent"),
             "Set ShoeGaze saturation drive (0-100%)")
        .def("get_shoegaze_drive", &Map2AudioEngine::getShoeGazeDrive,
             "Get ShoeGaze saturation drive")

        .def("set_shoegaze_delay_time", &Map2AudioEngine::setShoeGazeDelayTime,
             py::arg("ms"),
             "Set ShoeGaze delay time (0-1000ms)")
        .def("get_shoegaze_delay_time", &Map2AudioEngine::getShoeGazeDelayTime,
             "Get ShoeGaze delay time")

        .def("set_shoegaze_delay_feedback", &Map2AudioEngine::setShoeGazeDelayFeedback,
             py::arg("percent"),
             "Set ShoeGaze delay feedback (0-90%)")
        .def("get_shoegaze_delay_feedback", &Map2AudioEngine::getShoeGazeDelayFeedback,
             "Get ShoeGaze delay feedback")

        .def("set_shoegaze_delay_mod", &Map2AudioEngine::setShoeGazeDelayMod,
             py::arg("percent"),
             "Set ShoeGaze delay modulation/BBD wobble (0-100%)")
        .def("get_shoegaze_delay_mod", &Map2AudioEngine::getShoeGazeDelayMod,
             "Get ShoeGaze delay modulation")

        .def("set_shoegaze_low_cut", &Map2AudioEngine::setShoeGazeLowCut,
             py::arg("hz"),
             "Set ShoeGaze low cut frequency (20-2000 Hz)")
        .def("get_shoegaze_low_cut", &Map2AudioEngine::getShoeGazeLowCut,
             "Get ShoeGaze low cut frequency")

        .def("set_shoegaze_high_cut", &Map2AudioEngine::setShoeGazeHighCut,
             py::arg("hz"),
             "Set ShoeGaze high cut frequency (1000-20000 Hz)")
        .def("get_shoegaze_high_cut", &Map2AudioEngine::getShoeGazeHighCut,
             "Get ShoeGaze high cut frequency")

        .def("set_shoegaze_mix", &Map2AudioEngine::setShoeGazeMix,
             py::arg("percent"),
             "Set ShoeGaze wet/dry mix (0-100%)")
        .def("get_shoegaze_mix", &Map2AudioEngine::getShoeGazeMix,
             "Get ShoeGaze wet/dry mix")

        .def("set_shoegaze_stereo_width", &Map2AudioEngine::setShoeGazeStereoWidth,
             py::arg("percent"),
             "Set ShoeGaze stereo width (0-200%)")
        .def("get_shoegaze_stereo_width", &Map2AudioEngine::getShoeGazeStereoWidth,
             "Get ShoeGaze stereo width")

        // Advanced controls
        .def("set_shoegaze_reverb_diffusion", &Map2AudioEngine::setShoeGazeReverbDiffusion,
             py::arg("percent"),
             "Set ShoeGaze reverb diffusion (0-100%)")
        .def("get_shoegaze_reverb_diffusion", &Map2AudioEngine::getShoeGazeReverbDiffusion,
             "Get ShoeGaze reverb diffusion")

        .def("set_shoegaze_reverb_damping", &Map2AudioEngine::setShoeGazeReverbDamping,
             py::arg("percent"),
             "Set ShoeGaze reverb damping (0-100%)")
        .def("get_shoegaze_reverb_damping", &Map2AudioEngine::getShoeGazeReverbDamping,
             "Get ShoeGaze reverb damping")

        .def("set_shoegaze_shimmer_feedback", &Map2AudioEngine::setShoeGazeShimmerFeedback,
             py::arg("percent"),
             "Set ShoeGaze shimmer feedback/spiral (0-80%)")
        .def("get_shoegaze_shimmer_feedback", &Map2AudioEngine::getShoeGazeShimmerFeedback,
             "Get ShoeGaze shimmer feedback")

        .def("set_shoegaze_chorus_voices", &Map2AudioEngine::setShoeGazeChorusVoices,
             py::arg("voices"),
             "Set ShoeGaze chorus voice count (1-6)")
        .def("get_shoegaze_chorus_voices", &Map2AudioEngine::getShoeGazeChorusVoices,
             "Get ShoeGaze chorus voice count")

        .def("set_shoegaze_ducking", &Map2AudioEngine::setShoeGazeDucking,
             py::arg("percent"),
             "Set ShoeGaze ducking amount (0-100%)")
        .def("get_shoegaze_ducking", &Map2AudioEngine::getShoeGazeDucking,
             "Get ShoeGaze ducking amount")

        // Preset control
        .def("set_shoegaze_preset", [](Map2AudioEngine& self, const std::string& preset) {
            self.setShoeGazePreset(stringToShoegazePreset(preset));
        }, py::arg("preset"), "Set ShoeGaze preset by name")

        .def("get_shoegaze_preset", [](const Map2AudioEngine& self) {
            return shoegazePresetToString(self.getShoeGazePreset());
        }, "Get current ShoeGaze preset name")

        // Bypass and spillover
        .def("set_shoegaze_bypass", &Map2AudioEngine::setShoeGazeBypass,
             py::arg("bypass"),
             "Bypass ShoeGaze processor")
        .def("is_shoegaze_bypassed", &Map2AudioEngine::isShoeGazeBypassed,
             "Check if ShoeGaze is bypassed")

        .def("set_shoegaze_spillover", &Map2AudioEngine::setShoeGazeSpillover,
             py::arg("enabled"),
             "Enable ShoeGaze spillover (tails when bypassed)")
        .def("has_shoegaze_spillover", &Map2AudioEngine::hasShoeGazeSpillover,
             "Check if ShoeGaze spillover is enabled")

        // Bulk parameters
        .def("get_shoegaze_parameters", [](const Map2AudioEngine& self) {
            return shoegazeParamsToDict(self.getShoeGazeParameters());
        }, "Get all ShoeGaze parameters")

        .def("set_shoegaze_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setShoeGazeParameters(dictToShoegazeParams(params));
        }, py::arg("params"), "Set all ShoeGaze parameters at once")

        // Metering
        .def("get_shoegaze_metering", [](const Map2AudioEngine& self) {
            return shoegazeMeteringToDict(self.getShoeGazeMetering());
        }, "Get ShoeGaze metering data")

        // Preset info
        .def("get_shoegaze_presets", [](const Map2AudioEngine& /*self*/) {
            py::list result;
            int numPresets = Map2AudioEngine::getShoeGazeNumPresets();
            for (int i = 0; i < numPresets; ++i) {
                auto preset = static_cast<ShoeGazeProcessor::Preset>(i);
                auto info = Map2AudioEngine::getShoeGazePresetInfo(preset);
                py::dict d;
                d["id"] = shoegazePresetToString(preset);
                d["name"] = info.name ? std::string(info.name) : "";
                d["artist"] = info.artist ? std::string(info.artist) : "";
                d["description"] = info.description ? std::string(info.description) : "";
                result.append(d);
            }
            return result;
        }, "Get all available ShoeGaze presets")

        // ========================================
        // Lexi Love PCM 70 Reverb
        // ========================================

        // Algorithm control
        .def("set_lexilove_algorithm", [](Map2AudioEngine& self, int index) {
            self.setLexiLoveAlgorithm(index);
        }, py::arg("algorithm_index"), "Set Lexi Love algorithm by index (0-8)")

        .def("set_lexilove_algorithm_by_name", [](Map2AudioEngine& self, const std::string& name) {
            self.setLexiLoveAlgorithm(stringToLexiAlgorithm(name));
        }, py::arg("algorithm"), "Set Lexi Love algorithm by name")

        .def("get_lexilove_algorithm", &Map2AudioEngine::getLexiLoveAlgorithm,
             "Get current Lexi Love algorithm index")

        .def("get_lexilove_algorithm_name", [](const Map2AudioEngine& self) {
            return lexiAlgorithmToString(static_cast<LexiLoveProcessor::Algorithm>(self.getLexiLoveAlgorithm()));
        }, "Get current Lexi Love algorithm name")

        // Core parameters
        .def("set_lexilove_pre_delay", &Map2AudioEngine::setLexiLovePreDelay,
             py::arg("ms"),
             "Set Lexi Love pre-delay (0-500ms)")
        .def("get_lexilove_pre_delay", &Map2AudioEngine::getLexiLovePreDelay,
             "Get Lexi Love pre-delay")

        .def("set_lexilove_decay_time", &Map2AudioEngine::setLexiLoveDecayTime,
             py::arg("seconds"),
             "Set Lexi Love decay time (0.5-30s)")
        .def("get_lexilove_decay_time", &Map2AudioEngine::getLexiLoveDecayTime,
             "Get Lexi Love decay time")

        .def("set_lexilove_diffusion", &Map2AudioEngine::setLexiLoveDiffusion,
             py::arg("percent"),
             "Set Lexi Love diffusion (0-100%)")
        .def("get_lexilove_diffusion", &Map2AudioEngine::getLexiLoveDiffusion,
             "Get Lexi Love diffusion")

        .def("set_lexilove_mix", &Map2AudioEngine::setLexiLoveMix,
             py::arg("percent"),
             "Set Lexi Love wet/dry mix (0-100%)")
        .def("get_lexilove_mix", &Map2AudioEngine::getLexiLoveMix,
             "Get Lexi Love wet/dry mix")

        .def("set_lexilove_high_cut", &Map2AudioEngine::setLexiLoveHighCut,
             py::arg("hz"),
             "Set Lexi Love high cut frequency (1000-20000Hz)")
        .def("get_lexilove_high_cut", &Map2AudioEngine::getLexiLoveHighCut,
             "Get Lexi Love high cut frequency")

        .def("set_lexilove_low_cut", &Map2AudioEngine::setLexiLoveLowCut,
             py::arg("hz"),
             "Set Lexi Love low cut frequency (20-500Hz)")
        .def("get_lexilove_low_cut", &Map2AudioEngine::getLexiLoveLowCut,
             "Get Lexi Love low cut frequency")

        // Multi-band decay (Lexicon signature)
        .def("set_lexilove_low_decay_mult", &Map2AudioEngine::setLexiLoveLowDecayMult,
             py::arg("mult"),
             "Set Lexi Love low frequency decay multiplier (0.25-2.0)")
        .def("get_lexilove_low_decay_mult", &Map2AudioEngine::getLexiLoveLowDecayMult,
             "Get Lexi Love low frequency decay multiplier")

        .def("set_lexilove_high_decay_mult", &Map2AudioEngine::setLexiLoveHighDecayMult,
             py::arg("mult"),
             "Set Lexi Love high frequency decay multiplier (0.25-2.0)")
        .def("get_lexilove_high_decay_mult", &Map2AudioEngine::getLexiLoveHighDecayMult,
             "Get Lexi Love high frequency decay multiplier")

        .def("set_lexilove_low_crossover", &Map2AudioEngine::setLexiLoveLowCrossover,
             py::arg("hz"),
             "Set Lexi Love low crossover frequency (100-2000Hz)")
        .def("get_lexilove_low_crossover", &Map2AudioEngine::getLexiLoveLowCrossover,
             "Get Lexi Love low crossover frequency")

        .def("set_lexilove_high_crossover", &Map2AudioEngine::setLexiLoveHighCrossover,
             py::arg("hz"),
             "Set Lexi Love high crossover frequency (2000-15000Hz)")
        .def("get_lexilove_high_crossover", &Map2AudioEngine::getLexiLoveHighCrossover,
             "Get Lexi Love high crossover frequency")

        // Early reflections
        .def("set_lexilove_early_level", &Map2AudioEngine::setLexiLoveEarlyLevel,
             py::arg("percent"),
             "Set Lexi Love early reflection level (0-100%)")
        .def("get_lexilove_early_level", &Map2AudioEngine::getLexiLoveEarlyLevel,
             "Get Lexi Love early reflection level")

        .def("set_lexilove_early_pattern", &Map2AudioEngine::setLexiLoveEarlyPattern,
             py::arg("percent"),
             "Set Lexi Love early reflection pattern/density (0-100%)")
        .def("get_lexilove_early_pattern", &Map2AudioEngine::getLexiLoveEarlyPattern,
             "Get Lexi Love early reflection pattern")

        // Modulation (sparkle)
        .def("set_lexilove_mod_depth", &Map2AudioEngine::setLexiLoveModDepth,
             py::arg("percent"),
             "Set Lexi Love modulation depth for sparkle (0-100%)")
        .def("get_lexilove_mod_depth", &Map2AudioEngine::getLexiLoveModDepth,
             "Get Lexi Love modulation depth")

        .def("set_lexilove_mod_rate", &Map2AudioEngine::setLexiLoveModRate,
             py::arg("hz"),
             "Set Lexi Love modulation rate (0.1-10Hz)")
        .def("get_lexilove_mod_rate", &Map2AudioEngine::getLexiLoveModRate,
             "Get Lexi Love modulation rate")

        // State control
        .def("set_lexilove_bypass", &Map2AudioEngine::setLexiLoveBypass,
             py::arg("bypass"),
             "Bypass Lexi Love processor")
        .def("is_lexilove_bypassed", &Map2AudioEngine::isLexiLoveBypassed,
             "Check if Lexi Love is bypassed")

        .def("set_lexilove_spillover", &Map2AudioEngine::setLexiLoveSpillover,
             py::arg("enabled"),
             "Enable Lexi Love spillover (tails when bypassed)")
        .def("has_lexilove_spillover", &Map2AudioEngine::hasLexiLoveSpillover,
             "Check if Lexi Love spillover is enabled")

        // Bulk parameters
        .def("get_lexilove_parameters", [](const Map2AudioEngine& self) {
            return lexiParamsToDict(self.getLexiLoveParameters());
        }, "Get all Lexi Love parameters")

        .def("set_lexilove_parameters", [](Map2AudioEngine& self, const py::dict& params) {
            self.setLexiLoveParameters(dictToLexiParams(params));
        }, py::arg("params"), "Set all Lexi Love parameters at once")

        // Metering
        .def("get_lexilove_metering", [](const Map2AudioEngine& self) {
            return lexiMeteringToDict(self.getLexiLoveMetering());
        }, "Get Lexi Love metering data")

        // Algorithm info
        .def_static("get_lexilove_algorithms", []() {
            py::list algorithms;
            int numAlgorithms = Map2AudioEngine::getLexiLoveNumAlgorithms();
            for (int i = 0; i < numAlgorithms; ++i) {
                auto info = Map2AudioEngine::getLexiLoveAlgorithmInfo(i);
                py::dict d = lexiAlgorithmInfoToDict(info);
                d["index"] = i;
                d["id"] = lexiAlgorithmToString(static_cast<LexiLoveProcessor::Algorithm>(i));
                algorithms.append(d);
            }
            return algorithms;
        }, "Get all available Lexi Love algorithms")

        // ========================================
        // H3000 Ultra-Harmonizer Control
        // ========================================

        .def("set_h3000_bypass", &Map2AudioEngine::setH3000Bypass,
             py::arg("bypass"), "Bypass the H3000 processor")
        .def("is_h3000_bypassed", &Map2AudioEngine::isH3000Bypassed,
             "Check if H3000 is bypassed")

        // Algorithm selection (string overload)
        .def("set_h3000_algorithm", [](Map2AudioEngine& self, const std::string& algo) {
            self.setH3000Algorithm(stringToH3000Algorithm(algo));
        }, py::arg("algorithm"), "Set H3000 algorithm by name")

        // Algorithm selection (int overload)
        .def("set_h3000_algorithm", [](Map2AudioEngine& self, int algoIndex) {
            self.setH3000Algorithm(static_cast<H3000Processor::Algorithm>(algoIndex));
        }, py::arg("algorithm_index"), "Set H3000 algorithm by index (0-9)")

        .def("get_h3000_algorithm", [](const Map2AudioEngine& self) -> std::string {
            return h3000AlgorithmToString(static_cast<H3000Processor::Algorithm>(self.getH3000Algorithm()));
        }, "Get current H3000 algorithm")

        // Pitch parameters
        .def("set_h3000_pitch_l", &Map2AudioEngine::setH3000PitchL,
             py::arg("cents"), "Set left pitch shift in cents (-2400 to +2400)")
        .def("get_h3000_pitch_l", &Map2AudioEngine::getH3000PitchL,
             "Get left pitch shift in cents")
        .def("set_h3000_pitch_r", &Map2AudioEngine::setH3000PitchR,
             py::arg("cents"), "Set right pitch shift in cents (-2400 to +2400)")
        .def("get_h3000_pitch_r", &Map2AudioEngine::getH3000PitchR,
             "Get right pitch shift in cents")

        // Delay parameters
        .def("set_h3000_delay_l", &Map2AudioEngine::setH3000DelayL,
             py::arg("ms"), "Set left delay time in ms (0-1000)")
        .def("get_h3000_delay_l", &Map2AudioEngine::getH3000DelayL,
             "Get left delay time in ms")
        .def("set_h3000_delay_r", &Map2AudioEngine::setH3000DelayR,
             py::arg("ms"), "Set right delay time in ms (0-1000)")
        .def("get_h3000_delay_r", &Map2AudioEngine::getH3000DelayR,
             "Get right delay time in ms")

        // Feedback parameters
        .def("set_h3000_feedback", &Map2AudioEngine::setH3000Feedback,
             py::arg("percent"), "Set feedback amount (0-100)")
        .def("get_h3000_feedback", &Map2AudioEngine::getH3000Feedback,
             "Get feedback amount")
        .def("set_h3000_cross_feedback", &Map2AudioEngine::setH3000CrossFeedback,
             py::arg("percent"), "Set cross-channel feedback (0-100)")
        .def("get_h3000_cross_feedback", &Map2AudioEngine::getH3000CrossFeedback,
             "Get cross-channel feedback")

        // Modulation parameters
        .def("set_h3000_mod_depth", &Map2AudioEngine::setH3000ModDepth,
             py::arg("percent"), "Set modulation depth (0-100)")
        .def("get_h3000_mod_depth", &Map2AudioEngine::getH3000ModDepth,
             "Get modulation depth")
        .def("set_h3000_mod_rate", &Map2AudioEngine::setH3000ModRate,
             py::arg("hz"), "Set modulation rate in Hz (0.1-10)")
        .def("get_h3000_mod_rate", &Map2AudioEngine::getH3000ModRate,
             "Get modulation rate in Hz")

        // Filter parameters
        .def("set_h3000_low_cut", &Map2AudioEngine::setH3000LowCut,
             py::arg("hz"), "Set low cut frequency in Hz (20-500)")
        .def("get_h3000_low_cut", &Map2AudioEngine::getH3000LowCut,
             "Get low cut frequency in Hz")
        .def("set_h3000_high_cut", &Map2AudioEngine::setH3000HighCut,
             py::arg("hz"), "Set high cut frequency in Hz (2000-20000)")
        .def("get_h3000_high_cut", &Map2AudioEngine::getH3000HighCut,
             "Get high cut frequency in Hz")

        // Levels
        .def("set_h3000_mix", &Map2AudioEngine::setH3000Mix,
             py::arg("percent"), "Set wet/dry mix (0-100)")
        .def("get_h3000_mix", &Map2AudioEngine::getH3000Mix,
             "Get wet/dry mix")
        .def("set_h3000_level_l", &Map2AudioEngine::setH3000LevelL,
             py::arg("percent"), "Set left output level (0-100)")
        .def("get_h3000_level_l", &Map2AudioEngine::getH3000LevelL,
             "Get left output level")
        .def("set_h3000_level_r", &Map2AudioEngine::setH3000LevelR,
             py::arg("percent"), "Set right output level (0-100)")
        .def("get_h3000_level_r", &Map2AudioEngine::getH3000LevelR,
             "Get right output level")

        // Glide (portamento)
        .def("set_h3000_glide", &Map2AudioEngine::setH3000Glide,
             py::arg("ms"), "Set pitch glide time in ms (0-1000)")
        .def("get_h3000_glide", &Map2AudioEngine::getH3000Glide,
             "Get pitch glide time in ms")

        // Bulk parameters
        .def("get_h3000_parameters", [](const Map2AudioEngine& self) {
            return h3000ParamsToDict(self.getH3000Parameters());
        }, "Get all H3000 parameters")

        .def("set_h3000_parameters", [](Map2AudioEngine& self, const py::dict& params) {
            self.setH3000Parameters(dictToH3000Params(params));
        }, py::arg("params"), "Set all H3000 parameters at once")

        // Metering
        .def("get_h3000_metering", [](const Map2AudioEngine& self) {
            return h3000MeteringToDict(self.getH3000Metering());
        }, "Get H3000 metering data")

        // Algorithm info
        .def_static("get_h3000_algorithms", []() {
            py::list algorithms;
            int numAlgorithms = Map2AudioEngine::getH3000NumAlgorithms();
            for (int i = 0; i < numAlgorithms; ++i) {
                auto info = Map2AudioEngine::getH3000AlgorithmInfo(i);
                py::dict d = h3000AlgorithmInfoToDict(info);
                d["index"] = i;
                d["id"] = h3000AlgorithmToString(static_cast<H3000Processor::Algorithm>(i));
                algorithms.append(d);
            }
            return algorithms;
        }, "Get all available H3000 algorithms")

        // ========================================
        // Peavey 5150 Block Letter Amp Simulator
        // ========================================

        // Preamp controls
        .def("set_peavey5150_pre_gain", &Map2AudioEngine::setPeavey5150PreGain,
             py::arg("value"),
             "Set Peavey 5150 preamp gain (0-10)")
        .def("get_peavey5150_pre_gain", &Map2AudioEngine::getPeavey5150PreGain,
             "Get Peavey 5150 preamp gain")

        .def("set_peavey5150_post_gain", &Map2AudioEngine::setPeavey5150PostGain,
             py::arg("value"),
             "Set Peavey 5150 master volume (0-10)")
        .def("get_peavey5150_post_gain", &Map2AudioEngine::getPeavey5150PostGain,
             "Get Peavey 5150 master volume")

        // Tone stack
        .def("set_peavey5150_low", &Map2AudioEngine::setPeavey5150Low,
             py::arg("value"),
             "Set Peavey 5150 bass tone (0-10)")
        .def("get_peavey5150_low", &Map2AudioEngine::getPeavey5150Low,
             "Get Peavey 5150 bass tone")

        .def("set_peavey5150_mid", &Map2AudioEngine::setPeavey5150Mid,
             py::arg("value"),
             "Set Peavey 5150 mid tone (0-10)")
        .def("get_peavey5150_mid", &Map2AudioEngine::getPeavey5150Mid,
             "Get Peavey 5150 mid tone")

        .def("set_peavey5150_high", &Map2AudioEngine::setPeavey5150High,
             py::arg("value"),
             "Set Peavey 5150 treble tone (0-10)")
        .def("get_peavey5150_high", &Map2AudioEngine::getPeavey5150High,
             "Get Peavey 5150 treble tone")

        // Power amp
        .def("set_peavey5150_presence", &Map2AudioEngine::setPeavey5150Presence,
             py::arg("value"),
             "Set Peavey 5150 presence (0-10)")
        .def("get_peavey5150_presence", &Map2AudioEngine::getPeavey5150Presence,
             "Get Peavey 5150 presence")

        .def("set_peavey5150_resonance", &Map2AudioEngine::setPeavey5150Resonance,
             py::arg("value"),
             "Set Peavey 5150 resonance (0-10)")
        .def("get_peavey5150_resonance", &Map2AudioEngine::getPeavey5150Resonance,
             "Get Peavey 5150 resonance")

        .def("set_peavey5150_bias", &Map2AudioEngine::setPeavey5150Bias,
             py::arg("value"),
             "Set Peavey 5150 power tube bias (0-10, 0=cold stock)")
        .def("get_peavey5150_bias", &Map2AudioEngine::getPeavey5150Bias,
             "Get Peavey 5150 power tube bias")

        // Switches
        .def("set_peavey5150_bright", &Map2AudioEngine::setPeavey5150Bright,
             py::arg("on"),
             "Set Peavey 5150 bright switch")
        .def("get_peavey5150_bright", &Map2AudioEngine::getPeavey5150Bright,
             "Get Peavey 5150 bright switch state")

        // State
        .def("set_peavey5150_preset", [](Map2AudioEngine& self, const std::string& preset) {
            self.setPeavey5150Preset(stringToPeavey5150Preset(preset));
        }, py::arg("preset"), "Set Peavey 5150 preset by name")

        .def("get_peavey5150_preset", [](const Map2AudioEngine& self) {
            return peavey5150PresetToString(self.getPeavey5150Preset());
        }, "Get current Peavey 5150 preset name")

        .def("set_peavey5150_bypass", &Map2AudioEngine::setPeavey5150Bypass,
             py::arg("bypass"),
             "Bypass Peavey 5150 processor")
        .def("is_peavey5150_bypassed", &Map2AudioEngine::isPeavey5150Bypassed,
             "Check if Peavey 5150 is bypassed")

        // Bulk parameters
        .def("get_peavey5150_parameters", [](const Map2AudioEngine& self) {
            return peavey5150ParamsToDict(self.getPeavey5150Parameters());
        }, "Get all Peavey 5150 parameters")

        .def("set_peavey5150_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setPeavey5150Parameters(dictToPeavey5150Params(params));
        }, py::arg("params"), "Set all Peavey 5150 parameters at once")

        // Metering
        .def("get_peavey5150_metering", [](const Map2AudioEngine& self) {
            return peavey5150MeteringToDict(self.getPeavey5150Metering());
        }, "Get Peavey 5150 metering data")

        // Preset info
        .def("get_peavey5150_presets", [](const Map2AudioEngine& /*self*/) {
            py::list result;
            int numPresets = Map2AudioEngine::getPeavey5150NumPresets();
            for (int i = 0; i < numPresets; ++i) {
                auto preset = static_cast<Peavey5150Processor::Preset>(i);
                auto info = Map2AudioEngine::getPeavey5150PresetInfo(preset);
                py::dict d;
                d["id"] = peavey5150PresetToString(preset);
                d["name"] = info.name ? std::string(info.name) : "";
                d["description"] = info.description ? std::string(info.description) : "";
                result.append(d);
            }
            return result;
        }, "Get all available Peavey 5150 presets")

        // ========================================
        // Tweed Bassman 5F6-A Amplifier Simulator
        // ========================================

        // Channel
        .def("set_tweedbassman_channel_mode", &Map2AudioEngine::setTweedBassmanChannelMode, py::arg("mode"),
             "Set channel mode (0=Normal, 1=Bright, 2=Jumped)")
        .def("get_tweedbassman_channel_mode", &Map2AudioEngine::getTweedBassmanChannelMode)
        .def("set_tweedbassman_normal_volume", &Map2AudioEngine::setTweedBassmanNormalVolume, py::arg("value"))
        .def("get_tweedbassman_normal_volume", &Map2AudioEngine::getTweedBassmanNormalVolume)
        .def("set_tweedbassman_bright_volume", &Map2AudioEngine::setTweedBassmanBrightVolume, py::arg("value"))
        .def("get_tweedbassman_bright_volume", &Map2AudioEngine::getTweedBassmanBrightVolume)
        .def("set_tweedbassman_bright_cap", &Map2AudioEngine::setTweedBassmanBrightCap, py::arg("on"))
        .def("get_tweedbassman_bright_cap", &Map2AudioEngine::getTweedBassmanBrightCap)

        // Preamp
        .def("set_tweedbassman_v1_tube_type", &Map2AudioEngine::setTweedBassmanV1TubeType, py::arg("type"),
             "Set V1 tube (0=12AY7, 1=12AX7, 2=5751, 3=12AT7)")
        .def("get_tweedbassman_v1_tube_type", &Map2AudioEngine::getTweedBassmanV1TubeType)
        .def("set_tweedbassman_cathode_bypass", &Map2AudioEngine::setTweedBassmanCathodeBypass, py::arg("on"))
        .def("get_tweedbassman_cathode_bypass", &Map2AudioEngine::getTweedBassmanCathodeBypass)
        .def("set_tweedbassman_cathode_bias", &Map2AudioEngine::setTweedBassmanCathodeBias, py::arg("mode"),
             "Set cathode bias (0=Hot/820, 1=Normal/1.5k, 2=Cool/2.7k)")
        .def("get_tweedbassman_cathode_bias", &Map2AudioEngine::getTweedBassmanCathodeBias)

        // Tone
        .def("set_tweedbassman_treble", &Map2AudioEngine::setTweedBassmanTreble, py::arg("value"))
        .def("get_tweedbassman_treble", &Map2AudioEngine::getTweedBassmanTreble)
        .def("set_tweedbassman_mid", &Map2AudioEngine::setTweedBassmanMid, py::arg("value"))
        .def("get_tweedbassman_mid", &Map2AudioEngine::getTweedBassmanMid)
        .def("set_tweedbassman_bass", &Map2AudioEngine::setTweedBassmanBass, py::arg("value"))
        .def("get_tweedbassman_bass", &Map2AudioEngine::getTweedBassmanBass)
        .def("set_tweedbassman_raw_switch", &Map2AudioEngine::setTweedBassmanRawSwitch, py::arg("on"))
        .def("get_tweedbassman_raw_switch", &Map2AudioEngine::getTweedBassmanRawSwitch)

        // Master
        .def("set_tweedbassman_master_volume", &Map2AudioEngine::setTweedBassmanMasterVolume, py::arg("value"))
        .def("get_tweedbassman_master_volume", &Map2AudioEngine::getTweedBassmanMasterVolume)

        // Power amp
        .def("set_tweedbassman_presence", &Map2AudioEngine::setTweedBassmanPresence, py::arg("value"))
        .def("get_tweedbassman_presence", &Map2AudioEngine::getTweedBassmanPresence)
        .def("set_tweedbassman_nfb_mode", &Map2AudioEngine::setTweedBassmanNFBMode, py::arg("mode"),
             "Set NFB mode (0=Stock/27k, 1=None, 2=High/10k)")
        .def("get_tweedbassman_nfb_mode", &Map2AudioEngine::getTweedBassmanNFBMode)
        .def("set_tweedbassman_power_tube_type", &Map2AudioEngine::setTweedBassmanPowerTubeType, py::arg("type"),
             "Set power tube (0=6L6, 1=6V6, 2=EL34, 3=KT66)")
        .def("get_tweedbassman_power_tube_type", &Map2AudioEngine::getTweedBassmanPowerTubeType)
        .def("set_tweedbassman_bias_mode", &Map2AudioEngine::setTweedBassmanBiasMode, py::arg("mode"),
             "Set bias mode (0=Fixed, 1=Cathode)")
        .def("get_tweedbassman_bias_mode", &Map2AudioEngine::getTweedBassmanBiasMode)
        .def("set_tweedbassman_rectifier_type", &Map2AudioEngine::setTweedBassmanRectifierType, py::arg("type"),
             "Set rectifier (0=GZ34, 1=5U4G, 2=5Y3, 3=SS)")
        .def("get_tweedbassman_rectifier_type", &Map2AudioEngine::getTweedBassmanRectifierType)

        // Output
        .def("set_tweedbassman_output_level", &Map2AudioEngine::setTweedBassmanOutputLevel, py::arg("dB"))
        .def("get_tweedbassman_output_level", &Map2AudioEngine::getTweedBassmanOutputLevel)
        .def("set_tweedbassman_cabinet_enabled", &Map2AudioEngine::setTweedBassmanCabinetEnabled, py::arg("on"))
        .def("get_tweedbassman_cabinet_enabled", &Map2AudioEngine::getTweedBassmanCabinetEnabled)
        .def("set_tweedbassman_cabinet_ir", &Map2AudioEngine::setTweedBassmanCabinetIR, py::arg("index"))
        .def("get_tweedbassman_cabinet_ir", &Map2AudioEngine::getTweedBassmanCabinetIR)

        // State
        .def("set_tweedbassman_preset", [](Map2AudioEngine& self, const std::string& preset) {
            self.setTweedBassmanPreset(stringToTweedBassmanPreset(preset));
        }, py::arg("preset"), "Set Tweed Bassman preset by name")

        .def("get_tweedbassman_preset", [](const Map2AudioEngine& self) {
            return tweedBassmanPresetToString(self.getTweedBassmanPreset());
        }, "Get current Tweed Bassman preset name")

        .def("set_tweedbassman_bypass", &Map2AudioEngine::setTweedBassmanBypass, py::arg("bypass"))
        .def("is_tweedbassman_bypassed", &Map2AudioEngine::isTweedBassmanBypassed)

        // Bulk parameters
        .def("get_tweedbassman_parameters", [](const Map2AudioEngine& self) {
            return tweedBassmanParamsToDict(self.getTweedBassmanParameters());
        }, "Get all Tweed Bassman parameters")

        .def("set_tweedbassman_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setTweedBassmanParameters(dictToTweedBassmanParams(params));
        }, py::arg("params"), "Set all Tweed Bassman parameters at once")

        // Metering
        .def("get_tweedbassman_metering", [](const Map2AudioEngine& self) {
            return tweedBassmanMeteringToDict(self.getTweedBassmanMetering());
        }, "Get Tweed Bassman metering data")

        // Preset info
        .def("get_tweedbassman_presets", [](const Map2AudioEngine& /*self*/) {
            py::list result;
            int numPresets = Map2AudioEngine::getTweedBassmanNumPresets();
            for (int i = 0; i < numPresets; ++i) {
                auto preset = static_cast<TweedBassmanProcessor::Preset>(i);
                auto info = Map2AudioEngine::getTweedBassmanPresetInfo(preset);
                py::dict d;
                d["id"] = tweedBassmanPresetToString(preset);
                d["name"] = info.name ? std::string(info.name) : "";
                d["description"] = info.description ? std::string(info.description) : "";
                result.append(d);
            }
            return result;
        }, "Get all available Tweed Bassman presets")

        // ========================================
        // PassionFX Multi-Effect (Steve Vai Passion & Warfare)
        // ========================================

        // NoiseGate
        .def("set_passionfx_gate_enabled", &Map2AudioEngine::setPassionFXGateEnabled, py::arg("enabled"))
        .def("set_passionfx_gate_threshold", &Map2AudioEngine::setPassionFXGateThreshold, py::arg("dB"))
        .def("set_passionfx_gate_release", &Map2AudioEngine::setPassionFXGateRelease, py::arg("ms"))

        // Compressor
        .def("set_passionfx_comp_enabled", &Map2AudioEngine::setPassionFXCompEnabled, py::arg("enabled"))
        .def("set_passionfx_comp_threshold", &Map2AudioEngine::setPassionFXCompThreshold, py::arg("dB"))
        .def("set_passionfx_comp_ratio", &Map2AudioEngine::setPassionFXCompRatio, py::arg("ratio"))
        .def("set_passionfx_comp_attack", &Map2AudioEngine::setPassionFXCompAttack, py::arg("ms"))
        .def("set_passionfx_comp_release", &Map2AudioEngine::setPassionFXCompRelease, py::arg("ms"))
        .def("set_passionfx_comp_glassy", &Map2AudioEngine::setPassionFXCompGlassy, py::arg("glassy"))

        // Wah
        .def("set_passionfx_wah_enabled", &Map2AudioEngine::setPassionFXWahEnabled, py::arg("enabled"))
        .def("set_passionfx_wah_mode", &Map2AudioEngine::setPassionFXWahMode, py::arg("mode"))
        .def("set_passionfx_wah_position", &Map2AudioEngine::setPassionFXWahPosition, py::arg("position"))
        .def("set_passionfx_wah_q", &Map2AudioEngine::setPassionFXWahQ, py::arg("q"))

        // Phaser
        .def("set_passionfx_phaser_enabled", &Map2AudioEngine::setPassionFXPhaserEnabled, py::arg("enabled"))
        .def("set_passionfx_phaser_rate", &Map2AudioEngine::setPassionFXPhaserRate, py::arg("hz"))
        .def("set_passionfx_phaser_depth", &Map2AudioEngine::setPassionFXPhaserDepth, py::arg("depth"))
        .def("set_passionfx_phaser_stages", &Map2AudioEngine::setPassionFXPhaserStages, py::arg("stages"))
        .def("set_passionfx_phaser_feedback", &Map2AudioEngine::setPassionFXPhaserFeedback, py::arg("feedback"))

        // Chorus
        .def("set_passionfx_chorus_enabled", &Map2AudioEngine::setPassionFXChorusEnabled, py::arg("enabled"))
        .def("set_passionfx_chorus_rate", &Map2AudioEngine::setPassionFXChorusRate, py::arg("hz"))
        .def("set_passionfx_chorus_depth", &Map2AudioEngine::setPassionFXChorusDepth, py::arg("depth"))
        .def("set_passionfx_chorus_voices", &Map2AudioEngine::setPassionFXChorusVoices, py::arg("voices"))
        .def("set_passionfx_chorus_mix", &Map2AudioEngine::setPassionFXChorusMix, py::arg("mix"))

        // PitchShifter
        .def("set_passionfx_pitch_enabled", &Map2AudioEngine::setPassionFXPitchEnabled, py::arg("enabled"))
        .def("set_passionfx_pitch_semitones", &Map2AudioEngine::setPassionFXPitchSemitones, py::arg("semitones"))
        .def("set_passionfx_pitch_mix", &Map2AudioEngine::setPassionFXPitchMix, py::arg("mix"))

        // Harmonizer
        .def("set_passionfx_harm_enabled", &Map2AudioEngine::setPassionFXHarmEnabled, py::arg("enabled"))
        .def("set_passionfx_harm_voice1_interval", &Map2AudioEngine::setPassionFXHarmVoice1, py::arg("semitones"))
        .def("set_passionfx_harm_voice2_interval", &Map2AudioEngine::setPassionFXHarmVoice2, py::arg("semitones"))
        .def("set_passionfx_harm_detune_cents", &Map2AudioEngine::setPassionFXHarmDetune, py::arg("cents"))
        .def("set_passionfx_harm_mix", &Map2AudioEngine::setPassionFXHarmMix, py::arg("mix"))

        // Delay
        .def("set_passionfx_delay_enabled", &Map2AudioEngine::setPassionFXDelayEnabled, py::arg("enabled"))
        .def("set_passionfx_delay_time_l", &Map2AudioEngine::setPassionFXDelayTimeL, py::arg("ms"))
        .def("set_passionfx_delay_time_r", &Map2AudioEngine::setPassionFXDelayTimeR, py::arg("ms"))
        .def("set_passionfx_delay_feedback", &Map2AudioEngine::setPassionFXDelayFeedback, py::arg("feedback"))
        .def("set_passionfx_delay_mix", &Map2AudioEngine::setPassionFXDelayMix, py::arg("mix"))
        .def("set_passionfx_delay_freeze", &Map2AudioEngine::setPassionFXDelayFreeze, py::arg("freeze"))
        .def("set_passionfx_delay_pitch_shift_l", &Map2AudioEngine::setPassionFXDelayPitchShiftL, py::arg("semitones"))
        .def("set_passionfx_delay_pitch_shift_r", &Map2AudioEngine::setPassionFXDelayPitchShiftR, py::arg("semitones"))

        // Reverb
        .def("set_passionfx_reverb_enabled", &Map2AudioEngine::setPassionFXReverbEnabled, py::arg("enabled"))
        .def("set_passionfx_reverb_type", &Map2AudioEngine::setPassionFXReverbType, py::arg("type"))
        .def("set_passionfx_reverb_decay", &Map2AudioEngine::setPassionFXReverbDecay, py::arg("seconds"))
        .def("set_passionfx_reverb_shimmer_amount", &Map2AudioEngine::setPassionFXReverbShimmerAmount, py::arg("amount"))
        .def("set_passionfx_reverb_shimmer_interval", &Map2AudioEngine::setPassionFXReverbShimmerInterval, py::arg("semitones"))
        .def("set_passionfx_reverb_mix", &Map2AudioEngine::setPassionFXReverbMix, py::arg("mix"))
        .def("set_passionfx_reverb_freeze", &Map2AudioEngine::setPassionFXReverbFreeze, py::arg("freeze"))

        // EQ
        .def("set_passionfx_eq_enabled", &Map2AudioEngine::setPassionFXEqEnabled, py::arg("enabled"))
        .def("set_passionfx_eq_low_gain", &Map2AudioEngine::setPassionFXEqLowGain, py::arg("dB"))
        .def("set_passionfx_eq_mid_gain", &Map2AudioEngine::setPassionFXEqMidGain, py::arg("dB"))
        .def("set_passionfx_eq_high_gain", &Map2AudioEngine::setPassionFXEqHighGain, py::arg("dB"))
        .def("set_passionfx_eq_tilt", &Map2AudioEngine::setPassionFXEqTilt, py::arg("tilt"))

        // Exciter
        .def("set_passionfx_exciter_enabled", &Map2AudioEngine::setPassionFXExciterEnabled, py::arg("enabled"))
        .def("set_passionfx_exciter_warmth", &Map2AudioEngine::setPassionFXExciterWarmth, py::arg("warmth"))
        .def("set_passionfx_exciter_presence", &Map2AudioEngine::setPassionFXExciterPresence, py::arg("presence"))
        .def("set_passionfx_exciter_air", &Map2AudioEngine::setPassionFXExciterAir, py::arg("air"))

        // Tremolo
        .def("set_passionfx_trem_enabled", &Map2AudioEngine::setPassionFXTremEnabled, py::arg("enabled"))
        .def("set_passionfx_trem_rate", &Map2AudioEngine::setPassionFXTremRate, py::arg("hz"))
        .def("set_passionfx_trem_depth", &Map2AudioEngine::setPassionFXTremDepth, py::arg("depth"))
        .def("set_passionfx_trem_waveform", &Map2AudioEngine::setPassionFXTremWaveform, py::arg("waveform"))

        // Global
        .def("set_passionfx_mix", &Map2AudioEngine::setPassionFXMix, py::arg("mix"))
        .def("set_passionfx_output_level", &Map2AudioEngine::setPassionFXOutputLevel, py::arg("dB"))

        // State
        .def("set_passionfx_preset", [](Map2AudioEngine& self, const std::string& preset) {
            self.setPassionFXPreset(stringToPassionfxPreset(preset));
        }, py::arg("preset"), "Set PassionFX preset by name")

        .def("get_passionfx_preset", [](const Map2AudioEngine& self) {
            return passionfxPresetToString(self.getPassionFXPreset());
        }, "Get current PassionFX preset name")

        .def("set_passionfx_bypass", &Map2AudioEngine::setPassionFXBypass, py::arg("bypass"))
        .def("is_passionfx_bypassed", &Map2AudioEngine::isPassionFXBypassed)

        // Bulk parameters
        .def("get_passionfx_parameters", [](const Map2AudioEngine& self) {
            return passionfxParamsToDict(self.getPassionFXParameters());
        }, "Get all PassionFX parameters")

        .def("set_passionfx_parameters", [](Map2AudioEngine& self, py::dict params) {
            self.setPassionFXParameters(dictToPassionfxParams(params));
        }, py::arg("params"), "Set all PassionFX parameters at once")

        // Metering
        .def("get_passionfx_metering", [](const Map2AudioEngine& self) {
            return passionfxMeteringToDict(self.getPassionFXMetering());
        }, "Get PassionFX metering data")

        // Preset info
        .def("get_passionfx_presets", [](const Map2AudioEngine& /*self*/) {
            py::list result;
            int numPresets = Map2AudioEngine::getPassionFXNumPresets();
            for (int i = 0; i < numPresets; ++i) {
                auto preset = static_cast<PassionFXProcessor::Preset>(i);
                auto info = Map2AudioEngine::getPassionFXPresetInfo(preset);
                py::dict d;
                d["id"] = passionfxPresetToString(preset);
                d["name"] = info.name ? std::string(info.name) : "";
                d["track"] = info.track ? std::string(info.track) : "";
                d["description"] = info.description ? std::string(info.description) : "";
                result.append(d);
            }
            return result;
        }, "Get all available PassionFX presets")

        // ========================================
        // Pedalboard State (Legacy Compatibility)
        // ========================================

        .def("get_current_pedalboard", [](const Map2AudioEngine& self) {
            py::dict d;
            d["name"] = "Current Chain";
            d["input_volume_db"] = 0.0;
            d["output_volume_db"] = 0.0;

            py::list items;
            auto chain = self.getChainOrder();
            for (size_t i = 0; i < chain.size(); i++) {
                py::dict item;
                item["instance_id"] = chain[i];
                item["is_enabled"] = true;
                item["controls"] = py::list();
                items.append(item);
            }
            d["items"] = items;
            return d;
        }, "Get current pedalboard configuration");

    // ========================================
    // Factory Functions
    // ========================================

    m.def("create_engine", []() {
        return std::make_shared<Map2AudioEngine>();
    }, "Create a new audio engine instance");

    // ========================================
    // Module-level Functions
    // ========================================

    m.def("get_version", []() {
        return std::string(ENGINE_VERSION);
    }, "Get module version");

    m.def("is_available", []() {
        return true;
    }, "Check if module is available");

    m.def("db_to_linear", &dbToLinear,
          py::arg("db"),
          "Convert dB to linear amplitude");

    m.def("linear_to_db", &linearToDb,
          py::arg("linear"),
          "Convert linear amplitude to dB");

    m.def("samples_to_ms", &samplesToMs,
          py::arg("samples"), py::arg("sample_rate"),
          "Convert samples to milliseconds");

    m.def("ms_to_samples", &msToSamples,
          py::arg("ms"), py::arg("sample_rate"),
          "Convert milliseconds to samples");
}
